# Protatip8 Düzeltme Notu

Bu sürüm protatip7 üzerinde tespit edilen rapor-kod-çıktı tutarsızlıklarını azaltmak için hazırlanmıştır.

## Yapılan ana düzeltmeler

1. `PROJECT_NAME` protatip8 olarak güncellendi.
2. `main.py` başlangıcında eski `results/` klasörü temizleniyor. Böylece ana lokasyon modeli ile nöbetçi eczane çıktıları farklı çalıştırmalardan kalmıyor.
3. Nöbetçi eczane çizelgesi artık aynı çalıştırmada üretilen `results/service_loads.csv` dosyasındaki açık eczaneleri kullanıyor.
4. Gelişmiş nöbetçi eczane çıktı adları `protatip8` olarak değiştirildi:
   - `duty_schedule_protatip8.csv/xlsx`
   - `duty_pharmacy_summary_protatip8.csv`
   - `duty_coverage_summary_protatip8.csv`
   - `duty_model_protatip8_report.xlsx`
5. Rastgele maliyet sorunu azaltıldı. `cost_file` yoksa artık rastgele maliyet yerine deterministik proxy maliyet üretiliyor ve `data/opening_costs_proxy.xlsx` olarak kaydediliyor.
6. Ana modelde atama mantığı `sum_j y_ij = 1` olacak şekilde korunuyor. Bu, rapordaki `>= 1` ifadesinden daha temizdir.
7. Kapasite yorumları netleştirildi: `L = minimum kapasite`, `U = maksimum kapasite`.
8. Gelişmiş nöbetçi eczane algoritması sezgisel olarak tutuldu; MILP gibi sunulmamalıdır.
9. Nöbetçi kapsama yarıçapı ana modeldeki `max_dist=4000` ile uyumlu hale getirildi.
10. Solver sonucu raporda `solver_message` ile kontrol edilmelidir. Süre sınırına takılırsa “optimal” değil, “uygulanabilir çözüm” denmelidir.

## Rapor için doğru ifade

Bu sürüm için raporda şu ifade kullanılmalıdır:

> Ana lokasyon-atama problemi karma tam sayılı doğrusal programlama yapısında modellenmiştir. Nöbetçi eczane çizelgelemesi ise açılan eczaneler üzerinden kapsama, denge, dinlenme aralığı ve aynı gün minimum mesafe kriterlerini dikkate alan sezgisel bir çizelgeleme algoritmasıyla oluşturulmuştur.

## Çalıştırma

```bash
python main.py
```

Çalıştırma sonunda `results/` klasörü sıfırdan oluşur.
