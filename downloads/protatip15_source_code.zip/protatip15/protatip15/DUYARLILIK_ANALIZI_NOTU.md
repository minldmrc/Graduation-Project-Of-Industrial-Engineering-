# Protatip10 Duyarlılık Analizi Notu

Bu sürüm, Protatip8 modelini korur ve her `python main.py` çalıştırmasından sonra duyarlılık analizi için iki tabloyu otomatik günceller:

- `results/sensitivity_log.csv`
- `results/sensitivity_log.xlsx`

Her run öncesinde `main.py` içinde `SCENARIO_NAME` ve `ModelConfig` parametreleri değiştirilir. Eski duyarlılık kayıtlarının silinmemesi için `CLEAN_OLD_RESULTS = False` bırakılmıştır.

## Ana duyarlılık parametreleri

- `max_capacity`: Eczane başına maksimum talep yükü. Düşerse daha fazla eczane açılması beklenir.
- `max_dist`: Talep noktasının atanabileceği maksimum mesafe.
- `demand_scale`: Talep ağırlıklarını model içinde çarpar.
- `max_health_distance`: Açılacak eczanenin sağlık noktalarına maksimum uzaklığını sınırlar.
- `alpha`, `beta`, `gamma`, `delta`: Amaç fonksiyonundaki erişim, maksimum mesafe, maliyet ve sağlık yakınlığı ağırlıkları.

## Önerilen senaryolar

S0 baz senaryo:
```python
SCENARIO_NAME = "S0_baz_senaryo"
max_dist=4000.0
max_capacity=4.0
demand_scale=1.5
max_health_distance=2000.0
alpha=0.35
beta=0.34
gamma=0.01
delta=0.30
```

Kapasite:
```python
SCENARIO_NAME = "S1_kapasite_3"
max_capacity=3.0
```
```python
SCENARIO_NAME = "S2_kapasite_5"
max_capacity=5.0
```
```python
SCENARIO_NAME = "S3_kapasite_6"
max_capacity=6.0
```

Mesafe:
```python
SCENARIO_NAME = "S4_maxdist_3000"
max_dist=3000.0
```
```python
SCENARIO_NAME = "S5_maxdist_5000"
max_dist=5000.0
```

Talep:
```python
SCENARIO_NAME = "S6_demand_1_0"
demand_scale=1.0
```
```python
SCENARIO_NAME = "S7_demand_2_0"
demand_scale=2.0
```

Sağlık yakınlığı:
```python
SCENARIO_NAME = "S8_saglik_1500"
max_health_distance=1500.0
```
```python
SCENARIO_NAME = "S9_saglik_2500"
max_health_distance=2500.0
```
```python
SCENARIO_NAME = "S10_saglik_kisiti_yok"
max_health_distance=None
```

Amaç fonksiyonu ağırlıkları:
```python
SCENARIO_NAME = "S11_erisim_odakli"
alpha=0.55
beta=0.25
gamma=0.01
delta=0.19
```
```python
SCENARIO_NAME = "S12_adalet_odakli"
alpha=0.25
beta=0.55
gamma=0.01
delta=0.19
```
```python
SCENARIO_NAME = "S13_saglik_odakli"
alpha=0.25
beta=0.25
gamma=0.01
delta=0.49
```
```python
SCENARIO_NAME = "S14_maliyet_odakli"
alpha=0.34
beta=0.30
gamma=0.15
delta=0.21
```
