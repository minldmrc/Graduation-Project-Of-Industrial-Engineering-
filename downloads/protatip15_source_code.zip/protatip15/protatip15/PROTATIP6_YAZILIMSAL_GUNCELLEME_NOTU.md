# Protatip6 Yazılımsal Güncelleme Notu

Bu sürümde matematiksel modelin çıktı yapısı korunmuştur. `results` klasöründeki ana çıktı dosyaları ve kolon adları değiştirilmemiştir:

- `assignments.csv / assignments.xlsx`
- `service_loads.csv / service_loads.xlsx`
- `summary.csv / summary.xlsx`
- `model_results.xlsx`
- görseller ve HTML haritalar
- nöbetçi eczane çıktı dosyaları

## Yapılan yazılımsal hızlandırmalar

1. **Sparse MILP yapısı eklendi**
   - Eski model tüm `103 x 103 = 10609` adet `y_ij` atama değişkenini oluşturuyordu.
   - Protatip6 yalnızca gerçekten seçilebilir `y_ij` çiftlerini oluşturur.
   - `d_ij > max_dist` olan çiftler, eski modelde zaten `d_ij * y_ij <= MaxDist` nedeniyle seçilemezdi. Bu çiftler artık hiç değişken olarak açılmaz.

2. **Sağlık limiti dışındaki aday eczaneler baştan kapatıldı**
   - Eski modelde `health_distance_j * x_j <= max_health_distance` kısıtı kuruluyordu.
   - Protatip6'da bu koşulu sağlayamayan adayların `x_j` üst sınırı doğrudan `0` yapılır.
   - Bu matematiksel sonucu değiştirmez; sadece solver'ın gereksiz adayları denemesini engeller.

3. **Time-limit durumunda çıktı üretimi engellenmedi**
   - HiGHS süre sınırına ulaşsa bile geçerli bir çözüm bulduysa artık hata vermez.
   - Çıktılar yine aynı dosyalara yazılır.
   - `summary` içinde `solver_status` ve `solver_message` korunur.

4. **Koordinat ve mesafe matrisi gereksiz yere yeniden üretilmez**
   - `main.py` içinde `FORCE_REGENERATE_DATA = False` varsayılan yapıldı.
   - Dosyalar varsa tekrar Excel yazma/okuma yapılmaz.
   - Yeniden üretmek istersen `FORCE_REGENERATE_DATA = True` yapabilirsin.

5. **Solver ayarları config'e eklendi**
   - `time_limit_seconds`
   - `mip_rel_gap`
   - `solver_display`

## Terminalde göreceğin yeni bilgi

Model çalışırken şu satır basılır:

```text
Protatip6 sparse MILP: y_ij 7825/10609 çift oluşturuldu; 2784 gereksiz çift elendi; 23 sağlık limiti dışı aday kapatıldı.
```

Bu satır modelin daha küçük kurulduğunu gösterir.
