from pathlib import Path
from datetime import datetime

import pandas as pd

from src.pharmacy_location import ModelConfig, solve_pharmacy_location
from src.pharmacy_location.create_103_distance_matrix import create_distance_matrix
from src.pharmacy_location.data_loader import load_inputs
from src.pharmacy_location.advanced_duty_scheduler import DutyConfig, create_advanced_duty_schedule
from src.pharmacy_location.generate_103_coordinates import generate_coordinates
from src.pharmacy_location.visualization import (
    plot_load_distribution,
    plot_distance_histogram,
    create_map,
    create_gis_accessibility_map,
    plot_point_layout_from_coordinates,
    plot_assignment_lines_from_coordinates,
)


if __name__ == "__main__":
    PROJECT_NAME = "protatip15"

    COORDINATE_FILE = Path("data/103_talep_koordinatlari.xlsx")
    DISTANCE_FILE = Path("data/103_mesafe_matrisi.xlsx")
    IMPORTANT_PLACES_FILE = Path("data/important_places.csv")

    FORCE_REGENERATE_DATA = True
    CLEAN_OLD_RESULTS = True

    if CLEAN_OLD_RESULTS and Path("results").exists():
        import shutil
        shutil.rmtree("results")
        print("Eski results klasörü temizlendi; protatip15 çıktıları baştan üretilecek.")

    if FORCE_REGENERATE_DATA or not COORDINATE_FILE.exists():
        generate_coordinates(output_path=COORDINATE_FILE, seed=42)
    else:
        print(f"Koordinat dosyası mevcut, yeniden üretilmedi: {COORDINATE_FILE}")

    if FORCE_REGENERATE_DATA or not DISTANCE_FILE.exists():
        create_distance_matrix(
            coordinate_path=COORDINATE_FILE,
            output_path=DISTANCE_FILE,
        )
    else:
        print(f"Mesafe matrisi mevcut, yeniden üretilmedi: {DISTANCE_FILE}")

    # ============================================================
    # DUYARLILIK ANALIZI SENARYO ALANI
    # Her run öncesi sadece SCENARIO_NAME ve aşağıdaki parametreleri değiştir.
    # ============================================================

    SCENARIO_NAME = "S0_baz_senaryo"

    config = ModelConfig(
        distance_file=DISTANCE_FILE,
        weight_file=Path("data/agirlik.xlsx"),
        cost_file=Path("data/opening_costs_proxy.xlsx"),
        important_places_file=IMPORTANT_PLACES_FILE,
        results_dir=Path("results"),
        random_seed=42,

        max_dist=3000.0,
        min_capacity=1.0,
        max_capacity=4.0,
        demand_scale=1.5,
        max_pharmacies=41,
        max_health_distance=2000.0,

        alpha=0.35,
        beta=0.34,
        gamma=0.01,
        delta=0.30,

        preserve_exact_gams_assignment=False,
        time_limit_seconds=30.0,
        mip_rel_gap=0.02,
        solver_display=False,
    )

    # ============================================================
    # MODEL COZUMU
    # Infeasible olursa program çökmez, log dosyasına başarısız senaryo olarak yazar.
    # ============================================================

    try:
        solution = solve_pharmacy_location(config=config, save_outputs=True)
        optimization_success = True

    except Exception as e:
        print("\nUYARI: Bu senaryoda optimal çözüm bulunamadı.")
        print("Model infeasible veya solver başarısız oldu.")
        print("Hata mesajı:", str(e))

        solution = {
            "objective_value": None,
            "weighted_access_total": None,
            "max_assigned_distance": None,
            "total_opening_cost": None,
            "total_health_distance": None,
            "normalized_p_median": None,
            "normalized_p_center": None,
            "normalized_cost": None,
            "normalized_health_distance": None,
            "open_locations": [],
            "solver_status": "NOT_OPTIMAL",
            "solver_message": str(e),
        }

        optimization_success = False

    # ============================================================
    # DUYARLILIK ANALIZI LOG KAYDI
    # Her run sonunda CSV ve Excel dosyasına yeni satır ekler.
    # ============================================================

    config.results_dir.mkdir(parents=True, exist_ok=True)

    sensitivity_row = {
        "run_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "project_name": PROJECT_NAME,
        "scenario_name": SCENARIO_NAME,

        "max_dist": config.max_dist,
        "min_capacity": config.min_capacity,
        "max_capacity": config.max_capacity,
        "demand_scale": config.demand_scale,
        "max_pharmacies": config.max_pharmacies,
        "max_health_distance": config.max_health_distance,

        "alpha": config.alpha,
        "beta": config.beta,
        "gamma": config.gamma,
        "delta": config.delta,

        "time_limit_seconds": config.time_limit_seconds,
        "mip_rel_gap": config.mip_rel_gap,

        "optimization_success": optimization_success,
        "objective_value_F": solution["objective_value"],
        "weighted_access_total_A": solution["weighted_access_total"],
        "max_assigned_distance_Z": solution["max_assigned_distance"],
        "total_opening_cost_C": solution["total_opening_cost"],
        "total_health_distance_H": solution["total_health_distance"],

        "normalized_p_median": solution["normalized_p_median"],
        "normalized_p_center": solution["normalized_p_center"],
        "normalized_cost": solution["normalized_cost"],
        "normalized_health_distance": solution["normalized_health_distance"],

        "open_pharmacy_count": len(solution["open_locations"]),
        "open_pharmacy_locations": ", ".join(map(str, solution["open_locations"])),

        "solver_status": solution["solver_status"],
        "solver_message": solution["solver_message"],
    }

    log_csv_path = config.results_dir / "sensitivity_log.csv"
    log_excel_path = config.results_dir / "sensitivity_log.xlsx"

    new_row_df = pd.DataFrame([sensitivity_row])

    if log_csv_path.exists():
        old_df = pd.read_csv(log_csv_path, sep=";", encoding="utf-8-sig")
        log_df = pd.concat([old_df, new_row_df], ignore_index=True)
    else:
        log_df = new_row_df

    log_df.to_csv(log_csv_path, index=False, sep=";", encoding="utf-8-sig")

    try:
        log_df.to_excel(log_excel_path, index=False)
        excel_status = "Excel log güncellendi."
    except PermissionError:
        excel_status = "UYARI: sensitivity_log.xlsx açık olduğu için Excel güncellenemedi. CSV güncellendi."

    print("\nDuyarlılık analizi kaydı eklendi:")
    print(log_csv_path.resolve())
    print(log_excel_path.resolve())
    print(excel_status)

    # ============================================================
    # INFEASIBLE / BASARISIZ SENARYODA BURADA DUR
    # Boş çözümle harita, grafik, mesafe ve nöbet çizelgesi oluşturulmaz.
    # ============================================================

    if not optimization_success or len(solution["open_locations"]) == 0:
        print("\nBu senaryo infeasible/optimal değil.")
        print("Harita, mesafe grafikleri ve nöbet çizelgesi bu run için oluşturulmadı.")
        print("Senaryo sonucu sadece sensitivity_log dosyasına kaydedildi.")
        raise SystemExit

    # ============================================================
    # MESAFE KONTROLU
    # Sadece başarılı çözümde çalışır.
    # ============================================================

    data = load_inputs(config)
    distances = data["distances"]

    open_locations = solution["open_locations"]
    open_indices = [j - 1 for j in open_locations]

    nearest_open_distances = distances[:, open_indices].min(axis=1)

    print("\nAçılan eczanelere göre en yakın mesafeler:")
    print(nearest_open_distances)

    print("\nAçılan eczanelere göre en kötü mesafe:")
    print(nearest_open_distances.max())

    # ============================================================
    # MODEL SONUCLARI
    # ============================================================

    print("\nObjective value F:", solution["objective_value"])
    print("P-median component A:", solution["weighted_access_total"])
    print("P-center component Z:", solution["max_assigned_distance"])
    print("Cost component C:", solution["total_opening_cost"])
    print("Hospital/health proximity component H:", solution["total_health_distance"])
    print("Open pharmacy count:", len(solution["open_locations"]))
    print("Open pharmacy locations:", solution["open_locations"])
    print("Maximum assigned distance (Z):", solution["max_assigned_distance"])
    print("Results saved into:", config.results_dir.resolve())

    # ============================================================
    # GORSELLER VE HARITA
    # ============================================================

    plot_load_distribution()
    plot_distance_histogram()
    plot_point_layout_from_coordinates(COORDINATE_FILE)
    plot_assignment_lines_from_coordinates(COORDINATE_FILE)
    create_map(COORDINATE_FILE, IMPORTANT_PLACES_FILE)
    create_gis_accessibility_map(COORDINATE_FILE, IMPORTANT_PLACES_FILE)

    # ============================================================
    # GELISMIS NOBETCI ECZANE CIZELGESI
    # ============================================================

    create_advanced_duty_schedule(
        DutyConfig(
            service_loads_path=Path("results/service_loads.csv"),
            coordinate_path=COORDINATE_FILE,
            weight_path=Path("data/agirlik.xlsx"),
            important_places_path=IMPORTANT_PLACES_FILE,
            output_dir=Path("results"),
            number_of_days=30,
            pharmacies_per_day=2,
            coverage_radius_m=4000.0,
            hospital_coverage_radius_m=2500.0,
            min_pair_distance_m=900.0,
            rest_gap_days=1,
            weekend_weight=1.30,
            holiday_weight=1.70,
            holiday_days=(),
            time_limit_seconds=120,
        )
    )

    print(f"\nProje adı: {PROJECT_NAME}")
    print("Harita html olarak oluşturuldu -> results klasöründe")
    print("Görseller oluşturuldu -> results klasöründe")
    print("Protatip13 gelişmiş nöbetçi eczane çizelgesi oluşturuldu -> results klasöründe")