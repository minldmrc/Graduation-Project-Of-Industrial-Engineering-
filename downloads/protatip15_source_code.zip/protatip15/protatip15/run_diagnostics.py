from pathlib import Path

from src.pharmacy_location.config import ModelConfig
from src.pharmacy_location.diagnostics import run_feasibility_diagnostics


if __name__ == "__main__":
    config = ModelConfig(
        distance_file=Path("data/103_mesafe_matrisi.xlsx"),
        weight_file=Path("data/agirlik.xlsx"),
    )
    checks = run_feasibility_diagnostics(config)
    print(checks.to_string(index=False))
