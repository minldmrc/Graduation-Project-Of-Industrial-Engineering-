from pathlib import Path

from src.pharmacy_location.advanced_duty_scheduler import DutyConfig, create_advanced_duty_schedule


if __name__ == "__main__":
    create_advanced_duty_schedule(
        DutyConfig(
            service_loads_path=Path("results/service_loads.csv"),
            coordinate_path=Path("data/103_talep_koordinatlari.xlsx"),
            weight_path=Path("data/agirlik.xlsx"),
            important_places_path=Path("data/important_places.csv"),
            output_dir=Path("results"),
            number_of_days=30,
            pharmacies_per_day=2,
            coverage_radius_m=2500.0,
            hospital_coverage_radius_m=2000.0,
            min_pair_distance_m=900.0,
            rest_gap_days=1,
            weekend_weight=1.30,
            holiday_weight=1.70,
            holiday_days=(),
        )
    )
