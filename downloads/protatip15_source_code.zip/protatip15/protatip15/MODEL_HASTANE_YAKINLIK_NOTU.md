# protatip1 - Hastane / Sağlık Ocağı Yakınlığı Entegrasyonu

Bu sürümde harita tarafına `data/important_places.csv` dosyasındaki hastane ve sağlık merkezleri eklenmiştir.
Aynı dosya model tarafında da okunur.

## Yeni amaç fonksiyonu bileşeni

Önce her aday eczane konumu için en yakın hastane / sağlık noktası mesafesi hesaplanır:

\[
h_j = \min_{k \in K} d^{health}_{jk}
\]

Burada:

- \(j\): aday eczane konumu
- \(k\): hastane / sağlık ocağı / sağlık merkezi
- \(h_j\): aday eczane j'nin en yakın sağlık noktasına uzaklığı
- \(x_j\): aday konum j'de eczane açılırsa 1, açılmazsa 0

Modelin yeni normalize edilmiş amaç fonksiyonu:

\[
\min F =
\alpha \frac{A}{N_1}
+ \beta \frac{Z}{N_2}
+ \gamma \frac{C}{N_3}
+ \delta \frac{H}{N_4}
\]

Yeni hastane yakınlığı terimi:

\[
H = \sum_j h_j x_j
\]

Bu terim minimize edildiği için model, diğer koşullar aynıyken hastane ve sağlık merkezlerine daha yakın aday eczane noktalarını seçmeye eğilim gösterir.

## Kodda değişen ana dosyalar

- `src/pharmacy_location/config.py`
  - `important_places_file`
  - `delta`
  - `n4`

- `src/pharmacy_location/data_loader.py`
  - aday eczanelerin en yakın sağlık noktasına uzaklığını hesaplar

- `src/pharmacy_location/model.py`
  - amaç fonksiyonuna `delta * health_distances[j] / N4 * x_j` terimi eklenmiştir
  - sonuç dosyalarına `nearest_health_distance_m`, `total_health_distance_H`, `normalized_health_distance_H_over_N4` eklenmiştir

- `src/pharmacy_location/visualization.py`
  - `map.html` ve `gis_accessibility_map.html` içine hastane / sağlık noktaları eklenmiştir

- `main.py`
  - proje adı `protatip1`
  - `alpha=0.45`, `beta=0.35`, `gamma=0.10`, `delta=0.10`

## Sağlık noktası ekleme

Yeni hastane veya sağlık ocağı eklemek için `data/important_places.csv` dosyasına şu formatta satır ekle:

```csv
name;type;latitude;longitude
Örnek Sağlık Ocağı;Sağlık Ocağı;39.720000;43.050000
```
