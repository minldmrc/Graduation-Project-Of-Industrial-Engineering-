# Pharmacy Location Model - Python Version

This project converts the uploaded GAMS model into a Python mixed-integer programming implementation.

## Source GAMS model
The Python code was built from the uploaded GAMS file `bitirme projesi gerçek verilerle.gms`.

## Folder structure

```text
pharmacy_location_python/
├── data/
│   ├── 103_mesafe_matrisi.xlsx
│   └── agirlik.xlsx
├── results/
├── src/
│   └── pharmacy_location/
│       ├── __init__.py
│       ├── config.py
│       ├── data_loader.py
│       └── model.py
├── main.py
├── requirements.txt
└── README.md
```

## What each file does

- `config.py`: stores all model parameters from GAMS such as `P`, `MaxDist`, `L`, `U`, objective weights, and normalization values.
- `data_loader.py`: reads the Excel inputs and recreates the random cost vector `c(j)` from GAMS.
- `model.py`: builds and solves the MILP model using `scipy.optimize.milp`.
- `main.py`: project entry point. Run this file from Visual Studio Code.

## Mapping from GAMS to Python

### Sets
- `i /1*103/` -> demand point indices in NumPy/Pandas.
- `j /1*103/` -> candidate pharmacy location indices.

### Input data
- `d(i,j)` -> read from `103_mesafe_matrisi.xlsx`
- `w(i)` -> read from `agirlik.xlsx`
- `c(j)` -> random uniform cost array generated in Python with a fixed seed

### Decision variables
- `x(j)` -> binary vector for opening a pharmacy
- `y(i,j)` -> binary assignment matrix
- `Z` -> maximum assigned distance
- `S(j)` -> served demand at each open pharmacy

### Objective
The Python code keeps the same combined objective structure:

```text
alpha * [sum(d(i,j)*w(i)*y(i,j)) / N1]
+ beta  * [Z / N2]
+ gamma * [sum(c(j)*x(j)) / N3]
```

### Constraints
All constraints in the uploaded GAMS file are preserved:

1. each demand point assigned to at least one pharmacy
2. no assignment to a closed pharmacy
3. maximum number of opened pharmacies
4. p-center type max distance definition through `Z`
5. max acceptable distance
6. served-demand calculation
7. lower capacity bound
8. upper capacity bound

## Visual Studio Code setup

1. Open the folder `pharmacy_location_python` in VS Code.
2. Create a virtual environment:
   ```bash
   python -m venv .venv
   ```
3. Activate it:
   - Windows PowerShell:
     ```bash
     .venv\Scripts\Activate.ps1
     ```
4. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
5. Run the project:
   ```bash
   python main.py
   ```

## Output files
After solving, these files are written into `results/`:

- `summary.csv`
- `assignments.csv`
- `service_loads.csv`

## Important note
Your original GAMS model fails in the Community License because the model has more than 5000 rows/columns. Python does not have this GAMS license limit, so this conversion removes that blocker.

## Important modeling note
The original GAMS constraint is:

```text
sum(j, y(i,j)) =g= 1
```

This means a demand point may be assigned to more than one pharmacy. The Python project preserves that exact behavior by default with:

```python
preserve_exact_gams_assignment = True
```

If later you want a classic single-allocation model, set it to `False` and the code will use equality instead.


## Realistic normalized-data defaults

Because `agirlik.xlsx` sums to 100, the demand values behave like normalized shares rather than raw population counts. A practical starting configuration is:

- `max_dist = 300`
- `min_capacity = 1`
- `max_capacity = 5`
- `preserve_exact_gams_assignment = False`

This means each demand point is assigned to exactly one pharmacy, the service radius is compatible with the observed distance matrix, and pharmacy loads stay in a realistic band for normalized demand.


## Protatip7 notu

Protatip7, protatip6 çıktı yapısını korur. `data/agirlik.xlsx` değiştirilmeden `ModelConfig(demand_scale=1.5)` ile talep ağırlıkları model içinde ölçeklenir. Ayrıca `max_capacity=4.0`, `max_dist=4000`, `gamma=0.01`, `delta=0.30` ayarlarıyla 11 eczane gibi gerçeklikten kopuk düşük çözümleri azaltmak hedeflenmiştir.
