# Protatip14 - Batı Hastane Bölgesi Talep Noktası Düzeltmesi

Bu sürümde matematiksel model, amaç fonksiyonu ve kısıtlar değiştirilmedi. Yalnızca `data/103_talep_koordinatlari.xlsx` dosyasını üreten koordinat mantığı güncellendi.

## Yapılan değişiklik

- Batıdaki kırmızı ile işaretlenen bölge ve Ağrı Eğitim ve Araştırma Hastanesi çevresi boş bırakılmadı.
- Talep noktalarının önemli bir kısmı hastane çevresine ve batı-merkez geçiş koridoruna kaydırıldı.
- 12. Mekanize Piyade Tugay Komutanlığı / kışla alanı için tampon alan korunarak bu alanın içine nokta düşmesi engellendi.
- `103_mesafe_matrisi.xlsx` yeni koordinatlara göre yeniden üretildi.

## Değişen dosyalar

- `src/pharmacy_location/generate_103_coordinates.py`
- `data/103_talep_koordinatlari.xlsx`
- `data/103_mesafe_matrisi.xlsx`
- `main.py` içindeki proje adı `protatip14` olarak güncellendi.
