# Rapor Modeli ile Kod Uyumluluğu

Bu sürüm, rapordaki Bölüm 5 matematiksel modele göre düzenlenmiştir.

## Amaç fonksiyonu
Kod artık tek amaçlı `min Z` modeli değildir. Aşağıdaki normalized weighted-sum amaç fonksiyonunu kullanır:

F = alpha * (A / N1) + beta * (Z / N2) + gamma * (C / N3)

Burada:

- A = sum_i sum_j d_ij * W_i * y_ij  → P-median bileşeni
- Z = maksimum erişim mesafesi        → P-center bileşeni
- C = sum_j C_j * x_j                 → açılan eczane maliyeti

## Kısıtlar
Kodda şu kısıtlar bulunmaktadır:

1. Her talep noktası en az bir eczaneden hizmet alır.
2. Talep noktası yalnızca açık eczaneye atanabilir.
3. Açılacak eczane sayısı P üst sınırını aşamaz.
4. Atama mesafeleri Z değişkeni ile ilişkilendirilir.
5. Atama mesafeleri MaxDist değerini aşamaz.
6. Her açık eczanenin hizmet yükü hesaplanır.
7. Eczane hizmet yükü minimum ve maksimum kapasite aralığında tutulur.
8. x_j ve y_ij ikili karar değişkenleridir.

## Çıktılar
`results/summary.xlsx` ve `results/model_results.xlsx` içinde artık şu değerler de raporlanır:

- weighted_access_total_A
- max_assigned_distance_Z
- total_opening_cost_C
- normalized_p_median_A_over_N1
- normalized_p_center_Z_over_N2
- normalized_cost_C_over_N3
- alpha, beta, gamma
- N1, N2, N3

## Dosyalar
Ana değişiklikler:

- `src/pharmacy_location/config.py`
- `src/pharmacy_location/data_loader.py`
- `src/pharmacy_location/model.py`
- `main.py`
