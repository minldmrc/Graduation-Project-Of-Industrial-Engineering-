from __future__ import annotations

from pathlib import Path
import math
from itertools import combinations
from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(slots=True)
class DutyConfig:
    """Protatip8 gerçekçi nöbetçi eczane çizelgeleme ayarları."""

    service_loads_path: Path = Path("results/service_loads.csv")
    coordinate_path: Path = Path("data/103_talep_koordinatlari.xlsx")
    weight_path: Path = Path("data/agirlik.xlsx")
    important_places_path: Path | None = Path("data/important_places.csv")
    output_dir: Path = Path("results")

    number_of_days: int = 30
    pharmacies_per_day: int = 2

    # Gerçekçilik kısıtları
    coverage_radius_m: float = 2500.0          # Her talep noktası bu yarıçap içinde en az 1 nöbetçiye erişsin
    hospital_coverage_radius_m: float = 2000.0 # Her hastane/sağlık noktası bu yarıçap içinde en az 1 nöbetçiye erişsin
    min_pair_distance_m: float = 900.0         # Aynı gün seçilen nöbetçiler birbirine çok yakın olmasın
    rest_gap_days: int = 1                     # 1 => ardışık nöbet yok; 2 => arada en az 2 gün olsun

    # Amaç fonksiyonu cezaları
    uncovered_demand_penalty: float = 10000.0
    uncovered_hospital_penalty: float = 15000.0
    workload_balance_penalty: float = 10.0
    travel_distance_weight: float = 0.01
    hospital_distance_weight: float = 0.03

    # Gün ağırlıkları
    weekend_weight: float = 1.30
    holiday_weight: float = 1.70
    holiday_days: tuple[int, ...] = ()          # Örn: (1, 15, 30)

    time_limit_seconds: int = 120


def _read_csv_auto(path: Path) -> pd.DataFrame:
    """CSV dosyalarını ; veya , ayırıcıyla güvenli okur."""
    try:
        return pd.read_csv(path, sep=";")
    except Exception:
        return pd.read_csv(path)


def _haversine_matrix(lat1, lon1, lat2, lon2) -> np.ndarray:
    """İki koordinat kümesi arasındaki Haversine mesafesini metre olarak döndürür."""
    lat1 = np.radians(np.asarray(lat1, dtype=float))[:, None]
    lon1 = np.radians(np.asarray(lon1, dtype=float))[:, None]
    lat2 = np.radians(np.asarray(lat2, dtype=float))[None, :]
    lon2 = np.radians(np.asarray(lon2, dtype=float))[None, :]

    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    c = 2 * np.arcsin(np.sqrt(a))
    return 6371000.0 * c


def _load_weights(weight_path: Path, n: int) -> np.ndarray:
    if not weight_path.exists():
        return np.ones(n)
    df = pd.read_excel(weight_path)
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    if not numeric_cols:
        return np.ones(n)
    # id varsa son sayısal kolonu ağırlık olarak kullan
    col = numeric_cols[-1]
    w = df[col].to_numpy(dtype=float)
    if len(w) < n:
        return np.resize(w, n)
    return w[:n]


def _load_important_places(path: Path | None) -> pd.DataFrame:
    if path is None or not Path(path).exists():
        return pd.DataFrame(columns=["name", "type", "latitude", "longitude"])
    # Dosyanız ; ile kaydedilmiş; otomatik okuma güvenli olsun.
    df = pd.read_csv(path, sep=";")
    required = {"latitude", "longitude"}
    if not required.issubset(df.columns):
        return pd.DataFrame(columns=["name", "type", "latitude", "longitude"])
    return df.dropna(subset=["latitude", "longitude"]).reset_index(drop=True)



def create_advanced_duty_schedule(config: DutyConfig | None = None) -> dict[str, pd.DataFrame]:
    """
    Protatip8 gelişmiş nöbetçi eczane çizelgeleme modeli.

    Bu sürüm gerçek uygulamada hızlı çalışması için sezgisel-optimizasyon yaklaşımı kullanır.
    Dikkate alınan gerçekçilik bileşenleri:
    - Günlük sabit nöbetçi sayısı
    - Eczaneler arası dengeli nöbet sayısı
    - Ardışık nöbet / dinlenme aralığı
    - Aynı gün nöbetçi eczanelerin birbirine çok yakın olmaması
    - Talep noktalarının kapsanması
    - Hastane / sağlık noktası kapsaması
    - Hafta sonu ve özel günlerin daha ağır yük kabul edilmesi
    """
    cfg = config or DutyConfig()
    cfg.output_dir.mkdir(parents=True, exist_ok=True)

    if not cfg.service_loads_path.exists():
        raise FileNotFoundError(f"service_loads.csv bulunamadı: {cfg.service_loads_path.resolve()}")
    if not cfg.coordinate_path.exists():
        raise FileNotFoundError(f"Koordinat dosyası bulunamadı: {cfg.coordinate_path.resolve()}")

    loads = _read_csv_auto(cfg.service_loads_path)
    coords = pd.read_excel(cfg.coordinate_path)
    coords["id"] = coords["id"].astype(int)
    coord_map = coords.set_index("id")

    open_pharmacies = loads.loc[loads["open"] > 0.5, "pharmacy_location"].astype(int).tolist()
    if not open_pharmacies:
        raise ValueError("Açık eczane bulunamadı. Önce yer seçimi modeli çalıştırılmalıdır.")

    missing = [p for p in open_pharmacies if p not in coord_map.index]
    if missing:
        raise ValueError(f"Açık eczaneler için koordinat bulunamadı: {missing[:10]}")

    demand_ids = coords["id"].astype(int).tolist()
    demand_weights = _load_weights(cfg.weight_path, len(demand_ids))
    open_coords = coord_map.loc[open_pharmacies].reset_index()

    n_p = len(open_pharmacies)
    n_d = len(demand_ids)
    n_t = cfg.number_of_days

    demand_to_pharmacy = _haversine_matrix(coords["latitude"], coords["longitude"], open_coords["latitude"], open_coords["longitude"])
    pharmacy_to_pharmacy = _haversine_matrix(open_coords["latitude"], open_coords["longitude"], open_coords["latitude"], open_coords["longitude"])

    places = _load_important_places(cfg.important_places_path)
    n_h = len(places)
    if n_h > 0:
        hospital_to_pharmacy = _haversine_matrix(places["latitude"], places["longitude"], open_coords["latitude"], open_coords["longitude"])
    else:
        hospital_to_pharmacy = np.zeros((0, n_p))

    cover = demand_to_pharmacy <= cfg.coverage_radius_m
    hcover = hospital_to_pharmacy <= cfg.hospital_coverage_radius_m if n_h > 0 else np.zeros((0, n_p), dtype=bool)

    day_weights = np.ones(n_t)
    for t in range(n_t):
        day_no = t + 1
        if day_no % 7 in (6, 0):
            day_weights[t] = cfg.weekend_weight
        if day_no in cfg.holiday_days:
            day_weights[t] = cfg.holiday_weight

    total_duties = n_t * cfg.pharmacies_per_day
    min_duty = total_duties // n_p
    max_duty = math.ceil(total_duties / n_p)
    target_weighted = cfg.pharmacies_per_day * day_weights.sum() / n_p

    duty_count = np.zeros(n_p, dtype=int)
    weighted_load = np.zeros(n_p, dtype=float)
    last_duty_day = np.full(n_p, -999, dtype=int)
    r = np.zeros((n_p, n_t), dtype=int)

    mean_demand_dist = demand_to_pharmacy.mean(axis=0)
    mean_hospital_dist = hospital_to_pharmacy.mean(axis=0) if n_h > 0 else np.zeros(n_p)

    all_daily_sets = list(combinations(range(n_p), cfg.pharmacies_per_day))
    if not all_daily_sets:
        raise ValueError("pharmacies_per_day açık eczane sayısından büyük olamaz.")

    for t in range(n_t):
        best_set = None
        best_score = -1e100

        # Aşamalı gevşetme:
        # 0: kapasite dengesi + dinlenme + minimum çift mesafesi
        # 1: minimum çift mesafesi gevşer
        # 2: dinlenme gevşer
        # 3: maksimum nöbet dengesi de gevşer; her durumda çizelge üretilir
        for relaxation in range(4):
            for cand in all_daily_sets:
                cand = tuple(cand)

                if relaxation <= 2 and any(duty_count[j] >= max_duty for j in cand):
                    continue
                if relaxation <= 1 and any((t - last_duty_day[j]) <= cfg.rest_gap_days for j in cand):
                    continue
                if relaxation == 0:
                    too_close = any(
                        pharmacy_to_pharmacy[a, b] < cfg.min_pair_distance_m
                        for a, b in combinations(cand, 2)
                    )
                    if too_close:
                        continue

                demand_covered = cover[:, cand].any(axis=1)
                hospital_covered = hcover[:, cand].any(axis=1) if n_h > 0 else np.ones(0, dtype=bool)

                weighted_covered = float(demand_weights[demand_covered].sum())
                uncovered_demand = int((~demand_covered).sum())
                uncovered_hospital = int((~hospital_covered).sum()) if n_h > 0 else 0

                next_counts = duty_count[list(cand)] + 1
                next_weighted = weighted_load[list(cand)] + day_weights[t]
                balance_penalty = float(np.sum((next_weighted - target_weighted) ** 2))
                count_penalty = float(np.sum(next_counts ** 2))

                if len(cand) > 1:
                    min_pair = min(pharmacy_to_pharmacy[a, b] for a, b in combinations(cand, 2))
                    pair_bonus = min(min_pair, cfg.min_pair_distance_m) / max(cfg.min_pair_distance_m, 1.0)
                else:
                    pair_bonus = 1.0

                mean_distance_penalty = float(np.mean(mean_demand_dist[list(cand)]))
                mean_health_penalty = float(np.mean(mean_hospital_dist[list(cand)])) if n_h > 0 else 0.0

                score = (
                    1200.0 * weighted_covered
                    - cfg.uncovered_demand_penalty * uncovered_demand
                    - cfg.uncovered_hospital_penalty * uncovered_hospital
                    - cfg.workload_balance_penalty * balance_penalty
                    - 120.0 * count_penalty
                    + 250.0 * pair_bonus
                    - cfg.travel_distance_weight * mean_distance_penalty
                    - cfg.hospital_distance_weight * mean_health_penalty
                )

                if score > best_score:
                    best_score = score
                    best_set = cand

            if best_set is not None:
                break

        if best_set is None:
            best_set = tuple(sorted(range(n_p), key=lambda j: (duty_count[j], weighted_load[j]))[: cfg.pharmacies_per_day])

        for j in best_set:
            duty_count[j] += 1
            weighted_load[j] += day_weights[t]
            last_duty_day[j] = t
            r[j, t] = 1

    schedule_rows = []
    coverage_rows = []
    for t in range(n_t):
        selected_idx = np.where(r[:, t] == 1)[0]
        selected_ids = [open_pharmacies[j] for j in selected_idx]
        nearest = demand_to_pharmacy[:, selected_idx].min(axis=1)
        if n_h > 0:
            nearest_h = hospital_to_pharmacy[:, selected_idx].min(axis=1)
            uncovered_hospital_count = int((nearest_h > cfg.hospital_coverage_radius_m).sum())
        else:
            uncovered_hospital_count = 0

        row = {
            "day": t + 1,
            "day_weight": day_weights[t],
            "uncovered_demand_count": int((nearest > cfg.coverage_radius_m).sum()),
            "uncovered_hospital_count": uncovered_hospital_count,
        }
        for k, pharmacy_id in enumerate(selected_ids, start=1):
            row[f"duty_pharmacy_{k}"] = pharmacy_id
        schedule_rows.append(row)

        coverage_rows.append({
            "day": t + 1,
            "covered_demand_ratio": float((nearest <= cfg.coverage_radius_m).mean()),
            "weighted_covered_demand_ratio": float(demand_weights[nearest <= cfg.coverage_radius_m].sum() / demand_weights.sum()),
            "max_nearest_duty_distance_m": float(nearest.max()),
            "avg_nearest_duty_distance_m": float(nearest.mean()),
            "uncovered_demand_count": int((nearest > cfg.coverage_radius_m).sum()),
            "uncovered_hospital_count": uncovered_hospital_count,
        })

    schedule_df = pd.DataFrame(schedule_rows)
    coverage_df = pd.DataFrame(coverage_rows)

    summary_rows = []
    for j, pharmacy_id in enumerate(open_pharmacies):
        assigned_days = [t + 1 for t in range(n_t) if r[j, t] == 1]
        summary_rows.append({
            "pharmacy_location": pharmacy_id,
            "duty_count": int(r[j].sum()),
            "weighted_duty_load": float(weighted_load[j]),
            "assigned_days": ",".join(map(str, assigned_days)),
            "mean_distance_to_demand_m": float(mean_demand_dist[j]),
            "mean_distance_to_health_points_m": float(mean_hospital_dist[j]) if n_h > 0 else np.nan,
        })
    summary_df = pd.DataFrame(summary_rows)

    schedule_df.to_csv(cfg.output_dir / "duty_schedule_protatip8.csv", index=False, sep=";", encoding="utf-8-sig")
    schedule_df.to_excel(cfg.output_dir / "duty_schedule_protatip8.xlsx", index=False)
    summary_df.to_csv(cfg.output_dir / "duty_pharmacy_summary_protatip8.csv", index=False, sep=";", encoding="utf-8-sig")
    coverage_df.to_csv(cfg.output_dir / "duty_coverage_summary_protatip8.csv", index=False, sep=";", encoding="utf-8-sig")

    with pd.ExcelWriter(cfg.output_dir / "duty_model_protatip8_report.xlsx") as writer:
        schedule_df.to_excel(writer, sheet_name="schedule", index=False)
        summary_df.to_excel(writer, sheet_name="pharmacy_summary", index=False)
        coverage_df.to_excel(writer, sheet_name="coverage_summary", index=False)

    print("\nProtatip8 gelişmiş nöbetçi eczane modeli tamamlandı.")
    print(f"Çizelge: {(cfg.output_dir / 'duty_schedule_protatip8.xlsx').resolve()}")
    print(f"Rapor: {(cfg.output_dir / 'duty_model_protatip8_report.xlsx').resolve()}")

    return {
        "schedule": schedule_df,
        "pharmacy_summary": summary_df,
        "coverage_summary": coverage_df,
    }
