from pathlib import Path
import numpy as np
import pandas as pd


# Protatip14 notu:
# Matematiksel model değiştirilmemiştir. Bu dosya yalnızca haritada kullanılan
# 103 talep/ad aday koordinatını daha dengeli üretir. Noktalar yine aynı id
# mantığıyla hem talep noktası hem aday eczane lokasyonu olarak kullanılır.


def generate_coordinates(output_path="data/103_talep_koordinatlari.xlsx", seed=42):
    """
    Ağrı Merkez için 103 talep/ad aday noktası üretir.

    Protatip14 haritalama düzeltmeleri:
    - Batıdaki kırmızı ile işaretlenen alan artık boş bırakılmaz.
    - Ağrı Eğitim ve Araştırma Hastanesi çevresine ve hastane-merkez koridoruna
      anlamlı sayıda talep noktası eklenir.
    - Noktalar 12. Mekanize Piyade Tugay Komutanlığı / kışla tampon alanına girmez.
    - Matematiksel model, amaç fonksiyonu ve kısıtlar değiştirilmez; yalnızca
      talep/ad aday lokasyon koordinatları yeniden üretilir.
    """

    rng = np.random.default_rng(seed)
    points = []

    # Ağrı merkez harita sınırları
    lat_min, lat_max = 39.696, 39.748
    lon_min, lon_max = 43.006, 43.092

    # Batı kırmızı alanı tamamen kapatmamak için protatip13'teki batı yasak kutusu
    # daraltıldı. Yasaklanan kısım yalnızca kışla/tugay gövdesidir; hastane çevresi
    # ve kırmızı alanın güney/orta kısmı model talep noktaları için serbesttir.
    restricted_boxes = [
        {
            "name": "Bati 12. Mekanize Tugay / kisla tamponu",
            "lat_min": 39.7240,
            "lat_max": 39.7395,
            "lon_min": 43.0250,
            "lon_max": 43.0460,
        },
        {
            "name": "Dogu askeri alan tamponu",
            "lat_min": 39.7240,
            "lat_max": 39.7465,
            "lon_min": 43.0700,
            "lon_max": 43.0960,
        },
    ]

    def is_restricted(lat, lon):
        for area in restricted_boxes:
            if (
                area["lat_min"] <= lat <= area["lat_max"]
                and area["lon_min"] <= lon <= area["lon_max"]
            ):
                return True
        return False

    def sample_cluster(center_lat, center_lon, std_lat, std_lon, count):
        cluster_points = []
        attempts = 0
        max_attempts = count * 10000

        while len(cluster_points) < count:
            attempts += 1
            if attempts > max_attempts:
                raise RuntimeError(
                    "Koordinat üretimi çok fazla reddedildi. "
                    "Küme merkezi yasak alana çok yakın olabilir."
                )

            lat = rng.normal(center_lat, std_lat)
            lon = rng.normal(center_lon, std_lon)

            if not (lat_min <= lat <= lat_max and lon_min <= lon <= lon_max):
                continue

            if is_restricted(lat, lon):
                continue

            cluster_points.append((lat, lon))

        return cluster_points

    # 103 nokta dağılımı:
    # Kullanıcının işaretlediği batı kırmızı alan + hastane çevresi özellikle
    # güçlendirildi; merkez ve doğu tamamen boşaltılmadı.
    clusters = [
        # Batı kırmızı alan / Ağrı Eğitim ve Araştırma Hastanesi çevresi
        (39.7168, 43.0188, 0.0026, 0.0032, 15),
        # Batı kırmızı alanın orta-güneyi, tugay altından güvenli geçiş
        (39.7138, 43.0278, 0.0032, 0.0040, 14),
        # Batıdan merkeze doğal talep koridoru
        (39.7128, 43.0395, 0.0030, 0.0042, 11),

        # Merkez / ticari çekirdek
        (39.7195, 43.0520, 0.0040, 0.0040, 14),
        # Kuzey / Kazım Karabekir, batı tugaya kaçmadan
        (39.7330, 43.0550, 0.0038, 0.0042, 11),
        # Kuzeybatı yerleşim, kışla tamponu dışında
        (39.7285, 43.0485, 0.0032, 0.0032, 8),
        # Güney / Aşağı Küpkıran
        (39.7045, 43.0525, 0.0042, 0.0048, 12),
        # Güneydoğu / Mehmet Akif altı
        (39.7040, 43.0690, 0.0036, 0.0046, 9),
        # Doğu / Fırat-Mehmet Akif, askeri tampon dışında
        (39.7160, 43.0620, 0.0040, 0.0038, 9),
    ]

    for cluster in clusters:
        points += sample_cluster(*cluster)

    assert len(points) == 103, f"103 nokta bekleniyordu, {len(points)} üretildi."

    df = pd.DataFrame(points, columns=["latitude", "longitude"])
    df.insert(0, "id", range(1, len(df) + 1))
    df["latitude"] = df["latitude"].round(6)
    df["longitude"] = df["longitude"].round(6)

    # Son güvenlik kontrolü
    bad = df.apply(
        lambda r: is_restricted(float(r["latitude"]), float(r["longitude"])),
        axis=1,
    )
    if bad.any():
        raise RuntimeError(
            "Yasak alana düşen koordinat kaldı: "
            f"{df.loc[bad, 'id'].tolist()}"
        )

    # Batı alanının boş kalmadığını garanti eden kontrol
    west_area = (
        (df["latitude"].between(39.7060, 39.7235))
        & (df["longitude"].between(43.0100, 43.0415))
    )
    if int(west_area.sum()) < 25:
        raise RuntimeError(
            "Batı kırmızı alan/hastane çevresi yeterince temsil edilmedi: "
            f"{int(west_area.sum())} nokta"
        )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_excel(output_path, index=False)

    print(f"Koordinatlar oluşturuldu: {output_path}")
    print("Protatip14 kontrol: batı hastane bölgesi dolu, tugay/askeri alan içinde koordinat yok.")
    return df


if __name__ == "__main__":
    generate_coordinates()
