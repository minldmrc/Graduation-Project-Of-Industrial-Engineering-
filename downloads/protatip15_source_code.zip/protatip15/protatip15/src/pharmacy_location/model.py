from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix, vstack

from .config import ModelConfig
from .data_loader import load_inputs


class ModelBuildError(RuntimeError):
    """Raised when the optimization model cannot be constructed."""


def _eligible_pairs(
    distances: np.ndarray,
    max_dist: float,
    allowed_locations: np.ndarray,
) -> list[tuple[int, int]]:
    """Return only assignment pairs that can be selected in the original model.

    In the original full model, pairs with d_ij > max_dist are forced to y_ij = 0 by
    d_ij * y_ij <= MaxDist. Here they are not created at all. This preserves the
    mathematical feasible set while shrinking the MILP.
    """
    n_i, n_j = distances.shape
    pairs: list[tuple[int, int]] = []

    for i in range(n_i):
        for j in range(n_j):
            if allowed_locations[j] and distances[i, j] <= max_dist + 1e-9:
                pairs.append((i, j))

    return pairs


def _var_indexers(n_i: int, n_j: int, pairs: list[tuple[int, int]]) -> dict[str, Any]:
    n_x = n_j
    n_y = len(pairs)
    n_z = 1
    n_s = n_j

    start_x = 0
    start_y = start_x + n_x
    start_z = start_y + n_y
    start_s = start_z + n_z
    total = start_s + n_s

    pair_to_k = {pair: k for k, pair in enumerate(pairs)}

    def x_idx(j: int) -> int:
        return start_x + j

    def y_idx_by_k(k: int) -> int:
        return start_y + k

    def y_idx(i: int, j: int) -> int | None:
        k = pair_to_k.get((i, j))
        return None if k is None else start_y + k

    def z_idx() -> int:
        return start_z

    def s_idx(j: int) -> int:
        return start_s + j

    return {
        "x": x_idx,
        "y": y_idx,
        "yk": y_idx_by_k,
        "z": z_idx,
        "s": s_idx,
        "total": total,
        "start_x": start_x,
        "start_y": start_y,
        "start_z": start_z,
        "start_s": start_s,
        "n_x": n_x,
        "n_y": n_y,
        "n_s": n_s,
        "pairs": pairs,
        "pair_to_k": pair_to_k,
    }


def _build_objective(
    config: ModelConfig,
    distances: np.ndarray,
    weights: np.ndarray,
    costs: np.ndarray,
    health_distances: np.ndarray,
    normalization: dict[str, float],
    idx: dict[str, Any],
) -> np.ndarray:
    c = np.zeros(idx["total"], dtype=float)

    for k, (i, j) in enumerate(idx["pairs"]):
        c[idx["yk"](k)] = config.alpha * distances[i, j] * weights[i] / normalization["n1"]

    n_j = distances.shape[1]
    for j in range(n_j):
        c[idx["x"](j)] = (
            config.gamma * costs[j] / normalization["n3"]
            + config.delta * health_distances[j] / normalization["n4"]
        )

    c[idx["z"]()] = config.beta / normalization["n2"]
    return c


def _build_constraints(
    config: ModelConfig,
    distances: np.ndarray,
    weights: np.ndarray,
    idx: dict[str, Any],
) -> LinearConstraint:
    n_i, n_j = distances.shape
    pairs = idx["pairs"]
    n_y = len(pairs)
    rows = []
    lb_parts = []
    ub_parts = []

    # Constraint2(i): sum_j y(i,j) >= 1 veya = 1
    r_list: list[int] = []
    c_list: list[int] = []
    d_list: list[float] = []
    eligible_count_by_i = np.zeros(n_i, dtype=int)
    for k, (i, _j) in enumerate(pairs):
        r_list.append(i)
        c_list.append(idx["yk"](k))
        d_list.append(1.0)
        eligible_count_by_i[i] += 1

    if np.any(eligible_count_by_i == 0):
        missing = np.where(eligible_count_by_i == 0)[0] + 1
        raise ModelBuildError(
            "Bazı talep noktaları için max_dist ve sağlık limiti sonrası atanabilir eczane kalmadı: "
            + ", ".join(map(str, missing.tolist()))
        )

    rows.append(
        coo_matrix(
            (np.array(d_list), (np.array(r_list), np.array(c_list))),
            shape=(n_i, idx["total"]),
        )
    )
    if config.preserve_exact_gams_assignment:
        lb_parts.append(np.ones(n_i, dtype=float))
        ub_parts.append(np.full(n_i, np.inf))
    else:
        lb_parts.append(np.ones(n_i, dtype=float))
        ub_parts.append(np.ones(n_i, dtype=float))

    # Constraint3(i,j): y(i,j) - x(j) <= 0, only for active y variables.
    r = np.arange(n_y).repeat(2)
    c = np.empty(n_y * 2, dtype=int)
    data = np.empty(n_y * 2, dtype=float)
    for k, (_i, j) in enumerate(pairs):
        c[2 * k] = idx["yk"](k)
        c[2 * k + 1] = idx["x"](j)
        data[2 * k] = 1.0
        data[2 * k + 1] = -1.0
    rows.append(coo_matrix((data, (r, c)), shape=(n_y, idx["total"])))
    lb_parts.append(np.full(n_y, -np.inf))
    ub_parts.append(np.zeros(n_y, dtype=float))

    # Constraint4: sum_j x(j) <= P
    r = np.zeros(n_j, dtype=int)
    c = np.array([idx["x"](j) for j in range(n_j)], dtype=int)
    data = np.ones(n_j, dtype=float)
    rows.append(coo_matrix((data, (r, c)), shape=(1, idx["total"])))
    lb_parts.append(np.array([-np.inf]))
    ub_parts.append(np.array([config.max_pharmacies], dtype=float))

    # Constraint5(i,j): d(i,j)*y(i,j) - Z <= 0
    r = np.arange(n_y).repeat(2)
    c = np.empty(n_y * 2, dtype=int)
    data = np.empty(n_y * 2, dtype=float)
    for k, (i, j) in enumerate(pairs):
        c[2 * k] = idx["yk"](k)
        c[2 * k + 1] = idx["z"]()
        data[2 * k] = distances[i, j]
        data[2 * k + 1] = -1.0
    rows.append(coo_matrix((data, (r, c)), shape=(n_y, idx["total"])))
    lb_parts.append(np.full(n_y, -np.inf))
    ub_parts.append(np.zeros(n_y, dtype=float))

    # Constraint6 is represented by not creating d(i,j) > MaxDist y variables.

    # Constraint7(j): S(j) - sum_i w(i)*y(i,j) = 0
    r_list = []
    c_list = []
    d_list = []
    for j in range(n_j):
        r_list.append(j)
        c_list.append(idx["s"](j))
        d_list.append(1.0)
    for k, (i, j) in enumerate(pairs):
        r_list.append(j)
        c_list.append(idx["yk"](k))
        d_list.append(-weights[i])
    rows.append(
        coo_matrix(
            (np.array(d_list), (np.array(r_list), np.array(c_list))),
            shape=(n_j, idx["total"]),
        )
    )
    lb_parts.append(np.zeros(n_j, dtype=float))
    ub_parts.append(np.zeros(n_j, dtype=float))

    # Constraint8L(j): L*x(j) - S(j) <= 0
    r = np.arange(n_j).repeat(2)
    c = np.empty(n_j * 2, dtype=int)
    data = np.empty(n_j * 2, dtype=float)
    for j in range(n_j):
        c[2 * j] = idx["x"](j)
        c[2 * j + 1] = idx["s"](j)
        data[2 * j] = config.min_capacity
        data[2 * j + 1] = -1.0
    rows.append(coo_matrix((data, (r, c)), shape=(n_j, idx["total"])))
    lb_parts.append(np.full(n_j, -np.inf))
    ub_parts.append(np.zeros(n_j, dtype=float))

    # Constraint8U(j): S(j) - U*x(j) <= 0
    r = np.arange(n_j).repeat(2)
    c = np.empty(n_j * 2, dtype=int)
    data = np.empty(n_j * 2, dtype=float)
    for j in range(n_j):
        c[2 * j] = idx["s"](j)
        c[2 * j + 1] = idx["x"](j)
        data[2 * j] = 1.0
        data[2 * j + 1] = -config.max_capacity
    rows.append(coo_matrix((data, (r, c)), shape=(n_j, idx["total"])))
    lb_parts.append(np.full(n_j, -np.inf))
    ub_parts.append(np.zeros(n_j, dtype=float))

    A = vstack(rows, format="csc")
    lb = np.concatenate(lb_parts)
    ub = np.concatenate(ub_parts)
    return LinearConstraint(A, lb=lb, ub=ub)


def _build_bounds_and_integrality(
    idx: dict[str, Any],
    allowed_locations: np.ndarray,
) -> tuple[Bounds, np.ndarray]:
    lower = np.zeros(idx["total"], dtype=float)
    upper = np.full(idx["total"], np.inf, dtype=float)

    upper[idx["start_x"]: idx["start_y"]] = allowed_locations.astype(float)
    upper[idx["start_y"]: idx["start_z"]] = 1.0

    bounds = Bounds(lower, upper)
    integrality = np.zeros(idx["total"], dtype=int)
    integrality[idx["start_x"]: idx["start_z"]] = 1
    return bounds, integrality


def _extract_solution(
    result: Any,
    config: ModelConfig,
    data: dict[str, Any],
    idx: dict[str, Any],
) -> dict[str, Any]:
    n_i = data["n_demand"]
    n_j = data["n_locations"]

    x_vals = result.x[idx["start_x"]: idx["start_y"]]
    sparse_y_vals = result.x[idx["start_y"]: idx["start_z"]]
    y_vals = np.zeros((n_i, n_j), dtype=float)
    for k, (i, j) in enumerate(idx["pairs"]):
        y_vals[i, j] = sparse_y_vals[k]

    z_val = result.x[idx["z"]()]
    s_vals = result.x[idx["start_s"]: idx["total"]]

    open_locations = np.where(x_vals > 0.5)[0] + 1

    weighted_access_total = float(np.sum(data["distances"] * data["weights"][:, None] * y_vals))
    total_opening_cost = float(np.sum(data["costs"] * x_vals))
    total_health_distance = float(np.sum(data["health_distances"] * x_vals))
    normalization = data["normalization"]
    normalized_p_median = weighted_access_total / normalization["n1"]
    normalized_p_center = float(z_val) / normalization["n2"]
    normalized_cost = total_opening_cost / normalization["n3"]
    normalized_health_distance = total_health_distance / normalization["n4"]
    weighted_sum_objective = (
        config.alpha * normalized_p_median
        + config.beta * normalized_p_center
        + config.gamma * normalized_cost
        + config.delta * normalized_health_distance
    )

    assignment_rows = []
    for i in range(n_i):
        assigned = np.where(y_vals[i] > 0.5)[0] + 1
        for j in assigned:
            assignment_rows.append(
                {
                    "demand_point": i + 1,
                    "pharmacy_location": int(j),
                    "distance": float(data["distances"][i, j - 1]),
                    "weight": float(data["weights"][i]),
                }
            )

    service_rows = []
    for j in range(n_j):
        service_rows.append(
            {
                "pharmacy_location": j + 1,
                "open": int(round(x_vals[j])),
                "service_load": float(s_vals[j]),
                "cost": float(data["costs"][j]),
                "nearest_health_distance_m": float(data["health_distances"][j]),
            }
        )

    return {
        "objective_value": float(result.fun),
        "solver_status": int(result.status),
        "solver_message": str(result.message),
        "cost_source": data.get("cost_source", "unknown"),
        "max_assigned_distance": float(z_val),
        "weighted_access_total": weighted_access_total,
        "total_opening_cost": total_opening_cost,
        "total_health_distance": total_health_distance,
        "normalized_p_median": normalized_p_median,
        "normalized_p_center": normalized_p_center,
        "normalized_cost": normalized_cost,
        "normalized_health_distance": normalized_health_distance,
        "weighted_sum_objective_check": float(weighted_sum_objective),
        "normalization": normalization,
        "open_locations": open_locations.tolist(),
        "assignments": pd.DataFrame(assignment_rows),
        "service_loads": pd.DataFrame(service_rows),
        "x": x_vals,
        "y": y_vals,
        "z": z_val,
        "s": s_vals,
        "config": asdict(config),
    }


def _save_results(solution: dict[str, Any], results_dir: Path) -> None:
    results_dir.mkdir(parents=True, exist_ok=True)

    assignments = solution["assignments"]
    service_loads = solution["service_loads"]

    summary = pd.DataFrame(
        [
            {
                "objective_value": solution["objective_value"],
                "max_assigned_distance_Z": solution["max_assigned_distance"],
                "weighted_access_total_A": solution["weighted_access_total"],
                "total_opening_cost_C": solution["total_opening_cost"],
                "total_health_distance_H": solution["total_health_distance"],
                "normalized_p_median_A_over_N1": solution["normalized_p_median"],
                "normalized_p_center_Z_over_N2": solution["normalized_p_center"],
                "normalized_cost_C_over_N3": solution["normalized_cost"],
                "normalized_health_distance_H_over_N4": solution["normalized_health_distance"],
                "weighted_sum_objective_check": solution["weighted_sum_objective_check"],
                "N1": solution["normalization"]["n1"],
                "N2": solution["normalization"]["n2"],
                "N3": solution["normalization"]["n3"],
                "N4": solution["normalization"]["n4"],
                "alpha": solution["config"]["alpha"],
                "beta": solution["config"]["beta"],
                "gamma": solution["config"]["gamma"],
                "delta": solution["config"]["delta"],
                "open_pharmacy_count": len(solution["open_locations"]),
                "open_pharmacy_locations": ", ".join(map(str, solution["open_locations"])),
                "solver_status": solution["solver_status"],
                "solver_message": solution["solver_message"],
                "cost_source": solution.get("cost_source", "unknown"),
            }
        ]
    )

    assignments.to_csv(results_dir / "assignments.csv", index=False, sep=";", encoding="utf-8-sig")
    service_loads.to_csv(results_dir / "service_loads.csv", index=False, sep=";", encoding="utf-8-sig")
    summary.to_csv(results_dir / "summary.csv", index=False, sep=";", encoding="utf-8-sig")

    assignments.to_excel(results_dir / "assignments.xlsx", index=False)
    service_loads.to_excel(results_dir / "service_loads.xlsx", index=False)
    summary.to_excel(results_dir / "summary.xlsx", index=False)

    with pd.ExcelWriter(results_dir / "model_results.xlsx", engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="summary", index=False)
        assignments.to_excel(writer, sheet_name="assignments", index=False)
        service_loads.to_excel(writer, sheet_name="service_loads", index=False)


def _milp_options(config: ModelConfig) -> dict[str, Any]:
    options: dict[str, Any] = {}
    if getattr(config, "time_limit_seconds", None) is not None:
        options["time_limit"] = float(config.time_limit_seconds)
    if getattr(config, "mip_rel_gap", None) is not None:
        options["mip_rel_gap"] = float(config.mip_rel_gap)
    if getattr(config, "solver_display", None):
        options["disp"] = True
    return options


def solve_pharmacy_location(config: ModelConfig | None = None, save_outputs: bool = True) -> dict[str, Any]:
    config = config or ModelConfig()

    data = load_inputs(config)
    distances = data["distances"]
    weights = data["weights"]
    costs = data["costs"]
    health_distances = data["health_distances"]

    if config.max_health_distance is None:
        allowed_locations = np.ones(data["n_locations"], dtype=bool)
    else:
        allowed_locations = health_distances <= float(config.max_health_distance) + 1e-9

    pairs = _eligible_pairs(distances, config.max_dist, allowed_locations)
    idx = _var_indexers(data["n_demand"], data["n_locations"], pairs)

    full_y_count = data["n_demand"] * data["n_locations"]
    eliminated = full_y_count - len(pairs)
    blocked_locations = int(np.sum(~allowed_locations))
    print(
        f"Protatip8 sparse MILP: y_ij {len(pairs)}/{full_y_count} çift oluşturuldu; "
        f"{eliminated} gereksiz çift elendi; {blocked_locations} sağlık limiti dışı aday kapatıldı."
    )

    objective = _build_objective(config, distances, weights, costs, health_distances, data["normalization"], idx)
    constraints = _build_constraints(config, distances, weights, idx)
    bounds, integrality = _build_bounds_and_integrality(idx, allowed_locations)

    result = milp(
        c=objective,
        constraints=constraints,
        bounds=bounds,
        integrality=integrality,
        options=_milp_options(config),
    )

    # HiGHS time limit'e ulaşsa bile çoğu zaman geçerli bir incumbent çözüm döndürür.
    # Eski kod bu durumda hata verip çıktı üretmüyordu. Protatip6, geçerli çözüm varsa
    # aynı çıktı dosyalarını üretmeye devam eder; solver_status ve solver_message summary içinde kalır.
    if (not result.success) and result.x is None:
        raise ModelBuildError(
            f"Optimization did not finish successfully. Status={result.status}, message={result.message}"
        )

    solution = _extract_solution(result, config, data, idx)
    if save_outputs:
        _save_results(solution, Path(config.results_dir))
    return solution
