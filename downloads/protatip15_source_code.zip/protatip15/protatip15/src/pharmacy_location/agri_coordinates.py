from pathlib import Path
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def create_agri_coordinates(
    distance_file="data/103_mesafe_matrisi.xlsx",
    output_excel="results/agri_yaklasik_koordinatlar.xlsx",
    output_png="results/agri_yaklasik_koordinatlar_harita.png",
):
    """
    Mesafe matrisinden Ağrı için yaklaşık GPS formatlı koordinat üretir.
    Gerçek GPS değildir; matris yapısını koruyan GPSimsi koordinattır.
    """

    distance_file = Path(distance_file)
    output_excel = Path(output_excel)
    output_png = Path(output_png)

    output_excel.parent.mkdir(parents=True, exist_ok=True)

    if not distance_file.exists():
        raise FileNotFoundError(f"Mesafe matrisi bulunamadı: {distance_file}")

    df_raw = pd.read_excel(distance_file, header=None)

    # İlk satır/sütun etiketliyse otomatik temizleme
    matrix = df_raw.copy()

    if not pd.api.types.is_numeric_dtype(matrix.iloc[:, 0]):
        matrix = matrix.iloc[:, 1:]

    if not pd.api.types.is_numeric_dtype(matrix.iloc[0, :]):
        matrix = matrix.iloc[1:, :]

    matrix = matrix.apply(pd.to_numeric, errors="coerce")
    matrix = matrix.dropna(axis=0, how="all").dropna(axis=1, how="all")

    D = matrix.to_numpy(dtype=float)

    n = D.shape[0]
    labels = list(range(1, n + 1))

    np.fill_diagonal(D, 0)
    D = (D + D.T) / 2

    # Classical MDS
    J = np.eye(n) - np.ones((n, n)) / n
    B = -0.5 * J @ (D ** 2) @ J

    eigvals, eigvecs = np.linalg.eigh(B)
    idx = np.argsort(eigvals)[::-1]

    eigvals = eigvals[idx]
    eigvecs = eigvecs[:, idx]

    coords = eigvecs[:, :2] * np.sqrt(np.maximum(eigvals[:2], 0))
    coords = coords - coords.mean(axis=0)

    # Ağrı merkez çevresine ölçekleme
    target_radius_km = 18
    rmax = np.sqrt((coords ** 2).sum(axis=1)).max()

    if rmax > 0:
        coords_km = coords / rmax * target_radius_km
    else:
        coords_km = coords

    # Ağrı merkez yaklaşık koordinatı
    center_lat = 39.7191
    center_lon = 43.0503

    km_per_deg_lat = 111.32
    km_per_deg_lon = 111.32 * math.cos(math.radians(center_lat))

    lat = center_lat + coords_km[:, 1] / km_per_deg_lat
    lon = center_lon + coords_km[:, 0] / km_per_deg_lon

    result = pd.DataFrame({
        "nokta_id": labels,
        "x_km_goreceli": coords_km[:, 0],
        "y_km_goreceli": coords_km[:, 1],
        "yaklasik_enlem": lat,
        "yaklasik_boylam": lon,
    })

    result.to_excel(output_excel, index=False)

    plt.figure(figsize=(9, 7))
    plt.scatter(result["yaklasik_boylam"], result["yaklasik_enlem"], s=30)

    for _, row in result.iterrows():
        plt.text(
            row["yaklasik_boylam"],
            row["yaklasik_enlem"],
            str(int(row["nokta_id"])),
            fontsize=7
        )

    plt.title("Ağrı için Matristen Üretilmiş Yaklaşık Koordinatlar")
    plt.xlabel("Yaklaşık Boylam")
    plt.ylabel("Yaklaşık Enlem")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_png, dpi=200)
    plt.close()

    print(f"Yaklaşık koordinatlar oluşturuldu: {output_excel}")
    print(f"Harita görseli oluşturuldu: {output_png}")

    return result