from pathlib import Path
import requests
import pandas as pd
import folium


def fetch_agri_merkez_pharmacies(output_path="data/agri_merkez_eczaneler.csv"):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    query = """
    [out:json][timeout:60];

    area["name"="Ağrı"]["boundary"="administrative"]["admin_level"="4"]->.searchArea;

    (
      node["amenity"="pharmacy"](area.searchArea);
      way["amenity"="pharmacy"](area.searchArea);
      relation["amenity"="pharmacy"](area.searchArea);
    );

    out center tags;
    """

    url = "https://overpass-api.de/api/interpreter"

    headers = {
        "User-Agent": "pharmacy-project/1.0",
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    }

    response = requests.post(
        url,
        data=query.encode("utf-8"),
        headers=headers,
        timeout=90,
    )
    response.raise_for_status()

    data = response.json()

    rows = []

    for element in data.get("elements", []):
        tags = element.get("tags", {})

        lat = element.get("lat")
        lon = element.get("lon")

        if lat is None or lon is None:
            center = element.get("center", {})
            lat = center.get("lat")
            lon = center.get("lon")

        if lat is None or lon is None:
            continue

        lat = float(lat)
        lon = float(lon)

        # Sadece Ağrı Merkez
        if not (39.65 <= lat <= 39.78 and 43.00 <= lon <= 43.12):
            continue

        rows.append({
            "osm_id": element.get("id"),
            "osm_type": element.get("type"),
            "name": tags.get("name", "Unknown Pharmacy"),
            "latitude": lat,
            "longitude": lon,
            "phone": tags.get("phone", ""),
            "street": tags.get("addr:street", ""),
            "district": "Merkez",
            "city": "Ağrı",
        })

    df = pd.DataFrame(rows)

    if df.empty:
        print("Ağrı Merkez için eczane bulunamadı.")
        return df

    df = df.drop_duplicates(subset=["latitude", "longitude"])
    df = df.sort_values(by="name").reset_index(drop=True)

    df.to_csv(output_path, index=False, encoding="utf-8-sig", sep=";")

    excel_path = output_path.with_suffix(".xlsx")
    df.to_excel(excel_path, index=False)

    map_path = output_path.with_suffix(".html")
    create_pharmacy_map(df, map_path)

    print(f"{len(df)} eczane bulundu.")
    print(f"CSV dosyası kaydedildi: {output_path.resolve()}")
    print(f"Excel dosyası kaydedildi: {excel_path.resolve()}")
    print(f"HTML harita kaydedildi: {map_path.resolve()}")

    return df


def create_pharmacy_map(df, map_path="data/agri_merkez_eczaneler.html"):
    map_path = Path(map_path)

    center_lat = df["latitude"].mean()
    center_lon = df["longitude"].mean()

    pharmacy_map = folium.Map(
        location=[center_lat, center_lon],
        zoom_start=14,
        tiles="OpenStreetMap"
    )

    for _, row in df.iterrows():
        city = "Agri" if str(row.get("city", "")).lower() in {"ağrı", "agri"} else row.get("city", "")
        district = "Central" if str(row.get("district", "")).lower() in {"merkez", "central"} else row.get("district", "")
        popup_text = f"""
        <b>{row['name']}</b><br>
        City: {city}<br>
        District: {district}<br>
        Address: {row['street']}<br>
        Phone: {row['phone']}<br>
        Coordinates: {row['latitude']}, {row['longitude']}
        """

        folium.Marker(
            location=[row["latitude"], row["longitude"]],
            popup=folium.Popup(popup_text, max_width=300),
            tooltip=row["name"],
            icon=folium.Icon(color="red", icon="plus-sign")
        ).add_to(pharmacy_map)

    pharmacy_map.save(map_path)


if __name__ == "__main__":
    fetch_agri_merkez_pharmacies()