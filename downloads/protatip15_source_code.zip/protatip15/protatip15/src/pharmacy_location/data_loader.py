from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import ModelConfig


class InputDataError(RuntimeError):
    """Raised when Excel inputs do not match the expected GAMS structure."""


def _read_distance_matrix(path: Path) -> np.ndarray:
    raw = pd.read_excel(path, header=None)
    if raw.shape[0] < 2 or raw.shape[1] < 2:
        raise InputDataError(f"Distance matrix file is too small: {path}")

    matrix = raw.iloc[1:, 1:].apply(pd.to_numeric, errors="coerce")
    if matrix.isna().any().any():
        raise InputDataError(
            f"Distance matrix contains non-numeric values after removing row/column labels: {path}"
        )

    values = matrix.to_numpy(dtype=float)
    if values.shape[0] != values.shape[1]:
        raise InputDataError(
            f"Distance matrix must be square after trimming labels, got {values.shape} from {path}"
        )

    return values


def _read_weights(path: Path, expected_n: int) -> np.ndarray:
    raw = pd.read_excel(path, header=None)
    if raw.shape[1] < 2:
        raise InputDataError(f"Weight file must have at least two columns: {path}")

    weights = pd.to_numeric(raw.iloc[:, 1], errors="coerce")
    if weights.isna().any():
        raise InputDataError(f"Weight file contains non-numeric values in the weight column: {path}")
    if len(weights) != expected_n:
        raise InputDataError(
            f"Weight count ({len(weights)}) does not match distance matrix size ({expected_n})"
        )

    return weights.to_numpy(dtype=float)


def _read_costs(path: Path, expected_n: int) -> np.ndarray:
    raw = pd.read_excel(path, header=None)
    if raw.shape[1] < 2:
        raise InputDataError(f"Cost file must have at least two columns: {path}")

    costs = pd.to_numeric(raw.iloc[:, 1], errors="coerce")
    if costs.isna().any():
        raise InputDataError(f"Cost file contains non-numeric values in the cost column: {path}")
    if len(costs) != expected_n:
        raise InputDataError(
            f"Cost count ({len(costs)}) does not match distance matrix size ({expected_n})"
        )

    return costs.to_numpy(dtype=float)


def _build_proxy_costs(health_distances: np.ndarray, n_locations: int) -> np.ndarray:
    """
    Protatip8 maliyet yaklaşımı.

    Gerçek kira/işletme/lojistik maliyeti verisi yoksa rastgele maliyet üretmek yerine
    deterministik bir proxy kullanılır. Proxy, sağlık noktasına yakın bölgelerde açılış
    maliyetinin daha yüksek olabileceği varsayımına dayanır. Böylece aynı veriyle her
    çalıştırmada aynı C_j değerleri elde edilir ve raporda rastgele maliyet sorunu oluşmaz.
    """
    h = np.asarray(health_distances, dtype=float)
    if len(h) != n_locations or np.allclose(h.max(), h.min()):
        return np.full(n_locations, 3000.0, dtype=float)

    # Sağlık noktasına daha yakın adayların proxy maliyeti daha yüksek kabul edilir.
    h_norm = (h - h.min()) / max(h.max() - h.min(), 1.0)
    centrality_cost = 1.0 - h_norm
    return 1500.0 + 3500.0 * centrality_cost


def _save_proxy_costs(path: Path, costs: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame({"id": np.arange(1, len(costs) + 1), "cost": costs})
    df.to_excel(path, index=False, header=False)


def _haversine_distance_m(lat1: np.ndarray, lon1: np.ndarray, lat2: np.ndarray, lon2: np.ndarray) -> np.ndarray:
    """Enlem/boylam noktaları arasında metre cinsinden kuş uçuşu mesafe."""
    radius_m = 6371000.0
    lat1_rad = np.radians(lat1)
    lon1_rad = np.radians(lon1)
    lat2_rad = np.radians(lat2)
    lon2_rad = np.radians(lon2)

    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1_rad) * np.cos(lat2_rad) * np.sin(dlon / 2.0) ** 2
    c = 2.0 * np.arctan2(np.sqrt(a), np.sqrt(1.0 - a))
    return radius_m * c


def _read_important_places(path: Path) -> pd.DataFrame:
    if not path.exists():
        # visualization.load_important_places dosyayı oluşturuyor; burada döngüsel import yapmamak için sade hata veriyoruz.
        raise InputDataError(f"Important places file not found: {path}")

    places = pd.read_csv(path, sep=";")
    required = {"name", "type", "latitude", "longitude"}
    missing = required - set(places.columns)
    if missing:
        raise InputDataError(f"Important places file missing columns: {missing}")

    places = places.copy()
    places["latitude"] = pd.to_numeric(places["latitude"], errors="coerce")
    places["longitude"] = pd.to_numeric(places["longitude"], errors="coerce")
    places = places.dropna(subset=["latitude", "longitude"])
    if places.empty:
        raise InputDataError(f"Important places file has no valid coordinate rows: {path}")
    return places


def _read_candidate_coordinates(distance_file: Path, expected_n: int) -> pd.DataFrame | None:
    candidate_paths = [
        distance_file.parent / "103_talep_koordinatlari.xlsx",
        Path("data/103_talep_koordinatlari.xlsx"),
    ]
    for path in candidate_paths:
        if path.exists():
            coords = pd.read_excel(path)
            required = {"id", "latitude", "longitude"}
            if not required.issubset(coords.columns):
                continue
            coords = coords[["id", "latitude", "longitude"]].copy()
            coords["id"] = coords["id"].astype(int)
            coords = coords.sort_values("id")
            if len(coords) == expected_n:
                return coords
    return None


def _compute_health_distances(config: ModelConfig, distance_file: Path, expected_n: int) -> np.ndarray:
    """
    Her aday eczane konumu j için en yakın hastane/sağlık noktasına mesafeyi hesaplar.
    Bu değer amaç fonksiyonunda x_j ile çarpılır; düşük değer hastaneye yakın eczaneyi avantajlı yapar.
    """
    if config.important_places_file is None:
        return np.zeros(expected_n, dtype=float)

    coords = _read_candidate_coordinates(distance_file, expected_n)
    if coords is None:
        return np.zeros(expected_n, dtype=float)

    places = _read_important_places(Path(config.important_places_file))
    candidate_lat = coords["latitude"].to_numpy(dtype=float)[:, None]
    candidate_lon = coords["longitude"].to_numpy(dtype=float)[:, None]
    place_lat = places["latitude"].to_numpy(dtype=float)[None, :]
    place_lon = places["longitude"].to_numpy(dtype=float)[None, :]

    distances_to_places = _haversine_distance_m(candidate_lat, candidate_lon, place_lat, place_lon)
    return distances_to_places.min(axis=1).astype(float)


def _normalization_factors(
    config: ModelConfig,
    distances: np.ndarray,
    weights: np.ndarray,
    costs: np.ndarray,
    health_distances: np.ndarray,
) -> dict[str, float]:
    # Amaç A için kaba ölçek: tüm talebin en uzak mesafeye atanması
    auto_n1 = float(np.sum(weights) * max(np.max(distances), 1.0))
    # Amaç B için kaba ölçek: veri setindeki en büyük mesafe
    auto_n2 = float(max(np.max(distances), 1.0))
    # Amaç C için kaba ölçek: açılabilecek maksimum eczane sayısı * en büyük maliyet
    auto_n3 = float(max(config.max_pharmacies, 1) * max(np.max(costs), 1.0))
    # Amaç H için kaba ölçek: açılabilecek maksimum eczane sayısı * en büyük sağlık uzaklığı
    auto_n4 = float(max(config.max_pharmacies, 1) * max(np.max(health_distances), 1.0))

    return {
        "n1": float(config.n1 if config.n1 is not None else auto_n1),
        "n2": float(config.n2 if config.n2 is not None else auto_n2),
        "n3": float(config.n3 if config.n3 is not None else auto_n3),
        "n4": float(config.n4 if config.n4 is not None else auto_n4),
    }


def load_inputs(config: ModelConfig) -> dict[str, Any]:
    dist_path = Path(config.distance_file)
    weight_path = Path(config.weight_file)

    distances = _read_distance_matrix(dist_path)
    weights = _read_weights(weight_path, expected_n=distances.shape[0])

    demand_scale = float(getattr(config, "demand_scale", 1.0))
    if demand_scale <= 0:
        raise InputDataError("demand_scale must be positive.")
    weights = weights * demand_scale

    health_distances = _compute_health_distances(config, dist_path, expected_n=distances.shape[1])

    if config.cost_file is not None and Path(config.cost_file).exists():
        costs = _read_costs(Path(config.cost_file), expected_n=distances.shape[1])
        cost_source = "file"
    else:
        costs = _build_proxy_costs(health_distances, n_locations=distances.shape[1])
        cost_source = "deterministic_proxy"
        if config.cost_file is not None:
            _save_proxy_costs(Path(config.cost_file), costs)

    normalization = _normalization_factors(config, distances, weights, costs, health_distances)

    return {
        "distances": distances,
        "weights": weights,
        "costs": costs,
        "health_distances": health_distances,
        "normalization": normalization,
        "cost_source": cost_source,
        "n_demand": distances.shape[0],
        "n_locations": distances.shape[1],
    }
