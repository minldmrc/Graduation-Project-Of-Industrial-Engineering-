from pathlib import Path
import math
import pandas as pd
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds


def create_duty_schedule(
    service_loads_path="results/service_loads.csv",
    output_csv_path="results/duty_schedule.csv",
    output_excel_path="results/duty_schedule.xlsx",
    number_of_days=30,
    pharmacies_per_day=2,
    prevent_consecutive=True,
):
    """
    Açık eczaneler arasından dengeli nöbet çizelgesi oluşturur.
    """

    service_loads_path = Path(service_loads_path)

    if not service_loads_path.exists():
        raise FileNotFoundError(
            f"service_loads.csv bulunamadı: {service_loads_path.resolve()}"
        )

    loads = pd.read_csv(service_loads_path, sep=";")

    open_pharmacies = (
        loads.loc[loads["open"] > 0.5, "pharmacy_location"]
        .astype(int)
        .tolist()
    )

    if len(open_pharmacies) == 0:
        raise ValueError("Açık eczane bulunamadı. Önce lokasyon modeli çalışmalı.")

    n_pharmacies = len(open_pharmacies)
    n_days = number_of_days

    total_duties = n_days * pharmacies_per_day

    min_duty = total_duties // n_pharmacies
    max_duty = math.ceil(total_duties / n_pharmacies)

    # değişken: z[j,t]
    # index = j_index * n_days + t
    n_vars = n_pharmacies * n_days

    c = np.zeros(n_vars)

    integrality = np.ones(n_vars)

    bounds = Bounds(
        lb=np.zeros(n_vars),
        ub=np.ones(n_vars),
    )

    constraints = []
    lb = []
    ub = []

    def var_index(j_idx, t):
        return j_idx * n_days + t

    # 1. Her gün pharmacies_per_day kadar nöbetçi olsun
    for t in range(n_days):
        row = np.zeros(n_vars)
        for j_idx in range(n_pharmacies):
            row[var_index(j_idx, t)] = 1

        constraints.append(row)
        lb.append(pharmacies_per_day)
        ub.append(pharmacies_per_day)

    # 2. Her eczanenin toplam nöbet sayısı dengeli olsun
    for j_idx in range(n_pharmacies):
        row = np.zeros(n_vars)
        for t in range(n_days):
            row[var_index(j_idx, t)] = 1

        constraints.append(row)
        lb.append(min_duty)
        ub.append(max_duty)

    # 3. Aynı eczane art arda nöbet tutmasın
    if prevent_consecutive:
        for j_idx in range(n_pharmacies):
            for t in range(n_days - 1):
                row = np.zeros(n_vars)
                row[var_index(j_idx, t)] = 1
                row[var_index(j_idx, t + 1)] = 1

                constraints.append(row)
                lb.append(0)
                ub.append(1)

    A = np.vstack(constraints)

    linear_constraints = LinearConstraint(
        A,
        lb=np.array(lb),
        ub=np.array(ub),
    )

    result = milp(
        c=c,
        integrality=integrality,
        bounds=bounds,
        constraints=linear_constraints,
        options={"time_limit": 60},
    )

    if not result.success:
        raise RuntimeError(
            f"Nöbet çizelgesi oluşturulamadı. Status={result.status}, message={result.message}"
        )

    x = np.round(result.x).astype(int)

    schedule_rows = []

    for t in range(n_days):
        duty_pharmacies = []

        for j_idx, pharmacy in enumerate(open_pharmacies):
            if x[var_index(j_idx, t)] == 1:
                duty_pharmacies.append(pharmacy)

        row = {
            "day": t + 1,
        }

        for k, pharmacy in enumerate(duty_pharmacies, start=1):
            row[f"duty_pharmacy_{k}"] = pharmacy

        schedule_rows.append(row)

    schedule_df = pd.DataFrame(schedule_rows)

    output_csv_path = Path(output_csv_path)
    output_excel_path = Path(output_excel_path)

    output_csv_path.parent.mkdir(parents=True, exist_ok=True)

    schedule_df.to_csv(output_csv_path, index=False, sep=";", encoding="utf-8-sig")
    schedule_df.to_excel(output_excel_path, index=False)

    print(f"Nöbet çizelgesi oluşturuldu: {output_csv_path}")
    print(f"Nöbet çizelgesi Excel oluşturuldu: {output_excel_path}")


    return schedule_df

