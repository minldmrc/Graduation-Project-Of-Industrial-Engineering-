import pandas as pd
import matplotlib.pyplot as plt
import folium
from sklearn.manifold import MDS
from pathlib import Path


# ===============================
# 2D koordinat üret (MDS)
# ===============================
def build_2d_layout_from_distance_matrix(path="data/103_mesafe_matrisi.xlsx"):
    excel_path = Path(path)

    if not excel_path.exists():
        raise FileNotFoundError(
            f"Mesafe matrisi dosyası bulunamadı: {excel_path.resolve()}"
        )

    df = pd.read_excel(excel_path, header=None)

    labels = df.iloc[1:, 0].astype(int).tolist()
    dist_matrix = df.iloc[1:, 1:].astype(float).to_numpy()

    mds = MDS(
        n_components=2,
        dissimilarity="precomputed",
        random_state=42,
        normalized_stress="auto",
    )
    coords = mds.fit_transform(dist_matrix)

    return pd.DataFrame(
        {
            "node": labels,
            "x": coords[:, 0],
            "y": coords[:, 1],
        }
    )


# ===============================
# Nokta dağılımı (DOT GRAPH)
# ===============================
def plot_point_layout(path="data/103_mesafe_matrisi.xlsx"):
    coords = build_2d_layout_from_distance_matrix(path)
    loads = pd.read_csv("results/service_loads.csv", sep=";")

    open_nodes = loads.loc[loads["open"] > 0.5, "pharmacy_location"].astype(int)

    plt.figure(figsize=(10, 8))

    # tüm noktalar
    plt.scatter(coords["x"], coords["y"], s=18, alpha=0.7, label="Demand / candidate points")

    # seçilen eczaneler
    selected = coords[coords["node"].isin(open_nodes)]
    plt.scatter(selected["x"], selected["y"], s=140, marker="o", label="Selected pharmacies")

    for _, row in selected.iterrows():
        plt.text(row["x"], row["y"], str(int(row["node"])), fontsize=8)

    plt.title("Demand Points and Selected Pharmacy Locations")
    plt.xlabel("Dimension 1")
    plt.ylabel("Dimension 2")
    plt.legend()
    plt.tight_layout()
    plt.savefig("results/point_layout.png", dpi=300)
    plt.close()


# ===============================
# Atama çizgileri
# ===============================
def plot_assignment_lines(path="data/103_mesafe_matrisi.xlsx"):
    coords = build_2d_layout_from_distance_matrix(path)
    coords["node"] = coords["node"].astype(int)

    assignments = pd.read_csv("results/assignments.csv", sep=";")

    i_col = assignments.columns[0]
    j_col = assignments.columns[1]

    assignments = assignments.copy()
    assignments[i_col] = assignments[i_col].astype(int)
    assignments[j_col] = assignments[j_col].astype(int)

    coord_map = coords.set_index("node")[["x", "y"]].to_dict("index")

    plt.figure(figsize=(11, 9))
    plt.scatter(coords["x"], coords["y"], s=14, alpha=0.5, label="Demand points")

    for _, row in assignments.iterrows():
        i = row[i_col]
        j = row[j_col]

        if i in coord_map and j in coord_map:
            xi, yi = coord_map[i]["x"], coord_map[i]["y"]
            xj, yj = coord_map[j]["x"], coord_map[j]["y"]
            plt.plot([xi, xj], [yi, yj], linewidth=0.5, alpha=0.25)

    loads = pd.read_csv("results/service_loads.csv", sep=";")
    open_nodes = loads.loc[loads["open"] > 0.5, "pharmacy_location"].astype(int)
    selected = coords[coords["node"].isin(open_nodes)]

    plt.scatter(selected["x"], selected["y"], s=150, label="Selected pharmacies")

    for _, row in selected.iterrows():
        plt.text(row["x"], row["y"], str(int(row["node"])), fontsize=8)

    plt.title("Assignment of Demand Points to Selected Pharmacies")
    plt.xlabel("Dimension 1")
    plt.ylabel("Dimension 2")
    plt.legend()
    plt.tight_layout()
    plt.savefig("results/assignment_lines.png", dpi=300)
    plt.close()


# ===============================
# Eczane yük dağılımı
# ===============================
def plot_load_distribution():
    loads = pd.read_csv("results/service_loads.csv", sep=";")

    plt.figure(figsize=(12, 6))
    plt.bar(loads["pharmacy_location"], loads["service_load"])
    plt.xlabel("Pharmacy Location")
    plt.ylabel("Total Demand")
    plt.title("Pharmacy Load Distribution")
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.savefig("results/load_distribution.png", dpi=300)
    plt.close()


# ===============================
# Mesafe histogramı
# ===============================
def plot_distance_histogram():
    assignments = pd.read_csv("results/assignments.csv", sep=";")
    dist_col = assignments.columns[-1]

    plt.figure(figsize=(10, 6))
    plt.hist(assignments[dist_col], bins=20)
    plt.xlabel("Distance (meters)")
    plt.ylabel("Frequency")
    plt.title("Assignment Distance Distribution")
    plt.tight_layout()
    plt.savefig("results/distance_histogram.png", dpi=300)
    plt.close()


# ===============================
# Koordinat dosyasını oku
# ===============================
def load_real_coordinates(path="data/103_talep_koordinatlari.xlsx"):
    coord_path = Path(path)

    if not coord_path.exists():
        raise FileNotFoundError(
            f"Koordinat dosyası bulunamadı: {coord_path.resolve()}"
        )

    df = pd.read_excel(coord_path)

    required_columns = {"id", "latitude", "longitude"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(f"Koordinat dosyasında eksik kolon var: {missing}")

    df = df[["id", "latitude", "longitude"]].copy()
    df["id"] = df["id"].astype(int)
    return df


# ===============================
# Gerçek koordinatlarla nokta dağılımı
# ===============================
def plot_point_layout_from_coordinates(path="data/103_talep_koordinatlari.xlsx"):
    coords = load_real_coordinates(path)
    loads = pd.read_csv("results/service_loads.csv", sep=";")

    open_nodes = loads.loc[loads["open"] > 0.5, "pharmacy_location"].astype(int)

    plt.figure(figsize=(10, 8))
    plt.scatter(
        coords["longitude"],
        coords["latitude"],
        s=18,
        alpha=0.7,
        label="Demand / candidate points",
    )

    selected = coords[coords["id"].isin(open_nodes)]
    plt.scatter(
        selected["longitude"],
        selected["latitude"],
        s=140,
        marker="o",
        label="Selected pharmacies",
    )

    for _, row in selected.iterrows():
        plt.text(row["longitude"], row["latitude"], str(int(row["id"])), fontsize=8)

    plt.title("Demand Points and Selected Pharmacies by Real Coordinates")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.legend()
    plt.tight_layout()
    plt.savefig("results/point_layout.png", dpi=300)
    plt.close()


# ===============================
# Gerçek koordinatlarla atama çizgileri
# ===============================
def plot_assignment_lines_from_coordinates(path="data/103_talep_koordinatlari.xlsx"):
    coords = load_real_coordinates(path)
    assignments = pd.read_csv("results/assignments.csv", sep=";")
    loads = pd.read_csv("results/service_loads.csv", sep=";")

    i_col = "demand_point"
    j_col = "pharmacy_location"

    coord_map = coords.set_index("id")[["latitude", "longitude"]].to_dict("index")

    plt.figure(figsize=(11, 9))
    plt.scatter(
        coords["longitude"],
        coords["latitude"],
        s=14,
        alpha=0.5,
        label="Demand points",
    )

    for _, row in assignments.iterrows():
        i = int(row[i_col])
        j = int(row[j_col])

        if i in coord_map and j in coord_map:
            xi, yi = coord_map[i]["longitude"], coord_map[i]["latitude"]
            xj, yj = coord_map[j]["longitude"], coord_map[j]["latitude"]
            plt.plot([xi, xj], [yi, yj], linewidth=0.5, alpha=0.25)

    open_nodes = loads.loc[loads["open"] > 0.5, "pharmacy_location"].astype(int)
    selected = coords[coords["id"].isin(open_nodes)]

    plt.scatter(
        selected["longitude"],
        selected["latitude"],
        s=150,
        label="Selected pharmacies",
    )

    for _, row in selected.iterrows():
        plt.text(row["longitude"], row["latitude"], str(int(row["id"])), fontsize=8)

    plt.title("Assignment of Demand Points to Pharmacies by Real Coordinates")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.legend()
    plt.tight_layout()
    plt.savefig("results/assignment_lines.png", dpi=300)
    plt.close()


# ===============================
# Gerçek koordinatlarla HTML harita
# ===============================
def create_map(
    coordinate_path="data/103_talep_koordinatlari.xlsx",
    important_places_path="data/important_places.csv",
):
    assignments = pd.read_csv("results/assignments.csv", sep=";")
    coords_df = load_real_coordinates(coordinate_path)
    places_df = load_important_places(important_places_path)

    coord_map = coords_df.set_index("id")[["latitude", "longitude"]].to_dict("index")

    center_lat = coords_df["latitude"].mean()
    center_lon = coords_df["longitude"].mean()

    m = folium.Map(location=[center_lat, center_lon], zoom_start=12)

    open_nodes = sorted(assignments["pharmacy_location"].astype(int).unique())
    demand_nodes = sorted(assignments["demand_point"].astype(int).unique())

    # Talep noktaları
    for i in demand_nodes:
        if i not in coord_map:
            continue

        folium.CircleMarker(
            location=[coord_map[i]["latitude"], coord_map[i]["longitude"]],
            radius=3,
            fill=True,
            fill_opacity=0.7,
            popup=f"Demand point {i}",
        ).add_to(m)

    # Seçilen eczaneler
    for j in open_nodes:
        if j not in coord_map:
            continue

        folium.Marker(
            location=[coord_map[j]["latitude"], coord_map[j]["longitude"]],
            icon=folium.Icon(color="red", icon="plus-sign"),
            popup=f"Selected pharmacy {j}",
        ).add_to(m)

    # Atama çizgileri
    for _, row in assignments.iterrows():
        i = int(row["demand_point"])
        j = int(row["pharmacy_location"])

        if i in coord_map and j in coord_map:
            folium.PolyLine(
                locations=[
                    [coord_map[i]["latitude"], coord_map[i]["longitude"]],
                    [coord_map[j]["latitude"], coord_map[j]["longitude"]],
                ],
                weight=1,
                opacity=0.25,
            ).add_to(m)

    # Hospitals and health centers
    for _, row in places_df.iterrows():
        place_type = translate_place_type(row["type"])
        place_name = translate_place_name(row["name"])
        icon_color = "darkred" if "hospital" in place_type.lower() else "purple"
        folium.Marker(
            location=[float(row["latitude"]), float(row["longitude"])],
            icon=folium.Icon(color=icon_color, icon="plus-sign"),
            popup=f"<b>{place_name}</b><br><b>Type:</b> {place_type}",
            tooltip=f"{place_type}: {place_name}",
        ).add_to(m)

    folium.LayerControl(collapsed=False).add_to(m)
    add_map_legend(m)
    m.save("results/map.html")

# ===============================
# GIS erişilebilirlik haritası
# ===============================
def distance_to_color(distance_m):
    """Mesafeye göre GIS erişilebilirlik rengi döndürür."""
    if distance_m <= 500:
        return "green"
    if distance_m <= 1000:
        return "yellow"
    if distance_m <= 2000:
        return "orange"
    return "red"


def distance_to_category(distance_m):
    if distance_m <= 500:
        return "High accessibility (0-500 m)"
    if distance_m <= 1000:
        return "Moderate accessibility (500-1000 m)"
    if distance_m <= 2000:
        return "Low accessibility (1000-2000 m)"
    return "Very low accessibility (over 2000 m)"


def translate_place_type(place_type):
    text = str(place_type)
    normalized = text.lower()
    if "hastane" in normalized or "hospital" in normalized:
        return "Hospital"
    if "sağlık" in normalized or "saglik" in normalized or "health" in normalized:
        return "Health Center"
    return text


def translate_place_name(place_name):
    translations = {
        "Ağrı Eğitim ve Araştırma Hastanesi": "Agri Training and Research Hospital",
        "Ağrı Ağız ve Diş Sağlığı Merkezi": "Agri Oral and Dental Health Center",
        "Ağrı Merkez Toplum Sağlığı Merkezi": "Agri Central Community Health Center",
    }
    return translations.get(str(place_name), str(place_name))


def load_important_places(path="data/important_places.csv"):
    """
    Hastane, sağlık merkezi vb. önemli noktaları okur.
    Dosya yoksa Ağrı Merkez için başlangıç verisi oluşturur.
    Yeni yer eklemek için CSV'ye name,type,latitude,longitude satırı eklemen yeterli.
    """
    place_path = Path(path)

    if not place_path.exists():
        place_path.parent.mkdir(parents=True, exist_ok=True)
        default_places = pd.DataFrame([
            {
                "name": "Ağrı Eğitim ve Araştırma Hastanesi",
                "type": "Hospital",
                "latitude": 39.717007,
                "longitude": 43.017853,
            },
            {
                "name": "Ağrı Ağız ve Diş Sağlığı Merkezi",
                "type": "Health Center",
                "latitude": 39.722877,
                "longitude": 43.059369,
            },
            {
                "name": "Ağrı Merkez Toplum Sağlığı Merkezi",
                "type": "Health Center",
                "latitude": 39.717591,
                "longitude": 43.005021,
            },
        ])
        default_places.to_csv(place_path, sep=";", index=False, encoding="utf-8-sig")

    places = pd.read_csv(place_path, sep=";")
    required_columns = {"name", "type", "latitude", "longitude"}
    missing = required_columns - set(places.columns)
    if missing:
        raise ValueError(f"important_places.csv içinde eksik kolon var: {missing}")

    return places


def add_map_legend(m):
    legend_html = """
    <div style="position: fixed; bottom: 35px; left: 35px; z-index: 9999;
                background-color: white; padding: 12px; border: 2px solid #666;
                border-radius: 8px; font-size: 13px; box-shadow: 0 0 8px rgba(0,0,0,0.25);">
        <b>GIS Accessibility Legend</b><br>
        <span style="color:green; font-size:18px;">●</span> 0-500 m: high accessibility<br>
        <span style="color:#d6c800; font-size:18px;">●</span> 500-1000 m: moderate accessibility<br>
        <span style="color:orange; font-size:18px;">●</span> 1000-2000 m: low accessibility<br>
        <span style="color:red; font-size:18px;">●</span> over 2000 m: very low accessibility<br>
        <span style="color:blue; font-size:18px;">✚</span> Selected pharmacy<br>
        <span style="color:purple; font-size:18px;">✚</span> Hospital / health point
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))


def create_gis_accessibility_map(
    coordinate_path="data/103_talep_koordinatlari.xlsx",
    important_places_path="data/important_places.csv",
    output_path="results/gis_accessibility_map.html",
):
    """
    Mesafeye göre kırmızı/sarı/turuncu/yeşil renkli GIS erişilebilirlik haritası oluşturur.
    Ayrıca hastane ve sağlık merkezi gibi önemli yerleri ayrı katman olarak gösterir.
    """
    assignments = pd.read_csv("results/assignments.csv", sep=";")
    coords_df = load_real_coordinates(coordinate_path)
    places_df = load_important_places(important_places_path)

    coord_map = coords_df.set_index("id")[["latitude", "longitude"]].to_dict("index")
    center_lat = coords_df["latitude"].mean()
    center_lon = coords_df["longitude"].mean()

    m = folium.Map(location=[center_lat, center_lon], zoom_start=13, tiles="OpenStreetMap")

    demand_layer = folium.FeatureGroup(name="Demand points - colored by distance", show=True)
    pharmacy_layer = folium.FeatureGroup(name="Selected pharmacies", show=True)
    line_layer = folium.FeatureGroup(name="Assignment lines", show=False)
    places_layer = folium.FeatureGroup(name="Hospitals / key health points", show=True)

    open_nodes = sorted(assignments["pharmacy_location"].astype(int).unique())

    for _, row in assignments.iterrows():
        i = int(row["demand_point"])
        j = int(row["pharmacy_location"])
        distance_m = float(row["distance"])
        weight = float(row["weight"]) if "weight" in assignments.columns else 1.0

        if i not in coord_map:
            continue

        color = distance_to_color(distance_m)
        category = distance_to_category(distance_m)

        folium.CircleMarker(
            location=[coord_map[i]["latitude"], coord_map[i]["longitude"]],
            radius=5 + min(weight * 4, 4),
            color=color,
            fill=True,
            fill_color=color,
            fill_opacity=0.75,
            popup=(
                f"<b>Demand point:</b> {i}<br>"
                f"<b>Assigned pharmacy:</b> {j}<br>"
                f"<b>Distance:</b> {distance_m:.1f} m<br>"
                f"<b>Accessibility class:</b> {category}<br>"
                f"<b>Weight:</b> {weight:.3f}"
            ),
            tooltip=f"Point {i} | {distance_m:.0f} m | {category}",
        ).add_to(demand_layer)

        if j in coord_map:
            folium.PolyLine(
                locations=[
                    [coord_map[i]["latitude"], coord_map[i]["longitude"]],
                    [coord_map[j]["latitude"], coord_map[j]["longitude"]],
                ],
                color=color,
                weight=1,
                opacity=0.35,
                popup=f"Demand {i} → Pharmacy {j}: {distance_m:.1f} m",
            ).add_to(line_layer)

    for j in open_nodes:
        if j not in coord_map:
            continue
        folium.Marker(
            location=[coord_map[j]["latitude"], coord_map[j]["longitude"]],
            icon=folium.Icon(color="blue", icon="plus-sign"),
            popup=f"<b>Selected pharmacy:</b> {j}",
            tooltip=f"Selected pharmacy {j}",
        ).add_to(pharmacy_layer)

    for _, row in places_df.iterrows():
        place_type = translate_place_type(row["type"])
        place_name = translate_place_name(row["name"])
        folium.Marker(
            location=[float(row["latitude"]), float(row["longitude"])],
            icon=folium.Icon(color="purple", icon="plus-sign"),
            popup=f"<b>{place_name}</b><br><b>Type:</b> {place_type}",
            tooltip=f"{place_type}: {place_name}",
        ).add_to(places_layer)

    demand_layer.add_to(m)
    pharmacy_layer.add_to(m)
    places_layer.add_to(m)
    line_layer.add_to(m)
    folium.LayerControl(collapsed=False).add_to(m)
    add_map_legend(m)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    m.save(output_path)
    print(f"GIS erişilebilirlik haritası oluşturuldu: {output_path}")
