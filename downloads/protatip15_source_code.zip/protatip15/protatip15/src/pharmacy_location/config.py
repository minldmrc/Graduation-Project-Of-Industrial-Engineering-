from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class ModelConfig:
    """Rapor Bölüm 5'teki multi-objective MILP modelinin ayarları."""

    # Girdi dosyaları
    distance_file: Path = Path("data/103_mesafe_matrisi.xlsx")
    weight_file: Path = Path("data/agirlik.xlsx")
    cost_file: Path | None = None
    important_places_file: Path | None = Path("data/important_places.csv")

    # P ve MaxDist parametreleri
    max_pharmacies: int = 41
    max_dist: float = 4000.0

    # Sağlık noktasına yakınlık üst sınırı.
    # None bırakılırsa kısıt pasif olur; örn. 1500.0 => yalnızca en yakın sağlık noktasına
    # 1500 metre veya daha yakın aday eczaneler açılabilir.
    max_health_distance: float | None = None

    # Kapasite sınırları: L*x_j <= S_j <= U*x_j
    min_capacity: float = 1.0
    max_capacity: float = 8.0

    # Talep ağırlığı ölçek katsayısı.
    # Excel dosyasını değiştirmez; ağırlıklar yalnızca model belleğinde çarpılır.
    demand_scale: float = 1.0

    # Normalized weighted sum katsayıları: alpha + beta + gamma + delta = 1 önerilir
    alpha: float = 0.45  # P-median / toplam ağırlıklı erişim mesafesi
    beta: float = 0.35   # P-center / en uzak talep noktasının mesafesi
    gamma: float = 0.10  # Açılan eczane maliyeti
    delta: float = 0.10  # Hastane/sağlık noktasına yakınlık cezası

    # Normalizasyon katsayıları. None bırakılırsa veri üzerinden otomatik hesaplanır.
    n1: float | None = None
    n2: float | None = None
    n3: float | None = None
    n4: float | None = None

    # C_j maliyeti için cost_file yoksa deterministik rastgele maliyet üretilir.
    random_cost_low: float = 1000.0
    random_cost_high: float = 5000.0
    random_seed: int = 42

    # Rapordaki kısıt (2) >= 1 biçimindedir. False olduğunda pratikte tam 1 atama yapılır.
    preserve_exact_gams_assignment: bool = True

    # Solver / performans ayarları
    # None yaparsan solver süre sınırı olmadan tam optimal çözümü arar.
    time_limit_seconds: float | None = 120.0
    # 0.01 = %1 optimalite farkı kabul edilir; daha hızlı sonuç verir.
    # Tam optimal çözüm istersen 0.0 yapabilirsin.
    mip_rel_gap: float | None = 0.01
    # True yaparsan HiGHS solver loglarını terminalde gösterir.
    solver_display: bool = False

    # Çıktı klasörü
    results_dir: Path = Path("results")
