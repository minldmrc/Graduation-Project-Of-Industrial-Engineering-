from pathlib import Path

import numpy as np
import pandas as pd


def haversine(lat1, lon1, lat2, lon2):
    """İki enlem-boylam noktası arasındaki mesafeyi metre cinsinden hesaplar."""
    r = 6371000

    lat1 = np.radians(lat1)
    lon1 = np.radians(lon1)
    lat2 = np.radians(lat2)
    lon2 = np.radians(lon2)

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    c = 2 * np.arcsin(np.sqrt(a))

    return r * c


def create_distance_matrix(
    coordinate_path="data/103_talep_koordinatlari.xlsx",
    output_path="data/103_mesafe_matrisi.xlsx",
):
    """
    Koordinat Excel'inden 103x103 mesafe matrisi üretir.

    ÖNEMLİ:
    Modelin data_loader.py dosyası ilk satır ve ilk sütunu etiket kabul ediyor.
    Bu yüzden çıktı şu formatta yazılır:

        boş | 1 | 2 | 3 | ... | 103
         1 | 0 | d | d | ...
         2 | d | 0 | d | ...
    """
    coordinate_path = Path(coordinate_path)
    output_path = Path(output_path)

    if not coordinate_path.exists():
        raise FileNotFoundError(f"Koordinat dosyası bulunamadı: {coordinate_path.resolve()}")

    df = pd.read_excel(coordinate_path)

    required_columns = {"id", "latitude", "longitude"}
    missing = required_columns - set(df.columns)
    if missing:
        raise ValueError(f"Koordinat dosyasında eksik kolon var: {missing}")

    df = df.sort_values("id").reset_index(drop=True)
    ids = df["id"].astype(int).tolist()

    n = len(df)
    matrix = np.zeros((n, n), dtype=float)

    for i in range(n):
        for j in range(n):
            matrix[i, j] = haversine(
                df.loc[i, "latitude"],
                df.loc[i, "longitude"],
                df.loc[j, "latitude"],
                df.loc[j, "longitude"],
            )

    result = pd.DataFrame(matrix, index=ids, columns=ids)
    result.index.name = "id"

    output_path.parent.mkdir(parents=True, exist_ok=True)
    result.to_excel(output_path)

    print(f"Mesafe matrisi oluşturuldu: {output_path}")
    return result


if __name__ == "__main__":
    create_distance_matrix()
