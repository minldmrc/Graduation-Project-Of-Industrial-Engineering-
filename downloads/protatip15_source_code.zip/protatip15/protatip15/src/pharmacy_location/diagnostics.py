from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .config import ModelConfig
from .data_loader import load_inputs


def run_feasibility_diagnostics(config: ModelConfig | None = None) -> pd.DataFrame:
    config = config or ModelConfig()
    data = load_inputs(config)
    distances = data["distances"]
    weights = data["weights"]

    min_distance_per_demand = distances.min(axis=1)
    reachable_counts = (distances <= config.max_dist).sum(axis=1)

    checks = [
        {
            "check": "total_demand",
            "value": float(weights.sum()),
            "threshold_or_rule": "should be compatible with min/max capacity",
            "status": "info",
        },
        {
            "check": "min_capacity",
            "value": float(config.min_capacity),
            "threshold_or_rule": "must not exceed total demand for any opened facility pattern",
            "status": "problem" if config.min_capacity > weights.sum() else "ok",
        },
        {
            "check": "max_capacity",
            "value": float(config.max_capacity),
            "threshold_or_rule": "should be >= expected service load",
            "status": "ok",
        },
        {
            "check": "max_distance",
            "value": float(config.max_dist),
            "threshold_or_rule": "must allow enough candidate pharmacies per demand point",
            "status": "problem" if np.any(reachable_counts == 0) else "ok",
        },
        {
            "check": "reachable_candidates_min",
            "value": int(reachable_counts.min()),
            "threshold_or_rule": "each demand point should have at least 1 reachable candidate",
            "status": "problem" if reachable_counts.min() == 0 else "ok",
        },
        {
            "check": "reachable_candidates_max",
            "value": int(reachable_counts.max()),
            "threshold_or_rule": "higher values usually improve feasibility",
            "status": "info",
        },
        {
            "check": "nonself_distance_leq_maxdist",
            "value": int(((distances <= config.max_dist) & (~np.eye(distances.shape[0], dtype=bool))).sum()),
            "threshold_or_rule": "number of cross-assignments allowed by MaxDist",
            "status": "info",
        },
        {
            "check": "min_distance_excluding_self",
            "value": float(np.min(distances + np.eye(distances.shape[0]) * 1e15)),
            "threshold_or_rule": "smallest cross-distance in matrix",
            "status": "info",
        },
        {
            "check": "max_of_rowwise_min_distance",
            "value": float(min_distance_per_demand.max()),
            "threshold_or_rule": "worst best-case distance for any demand point",
            "status": "info",
        },
    ]

    return pd.DataFrame(checks)


if __name__ == "__main__":
    df = run_feasibility_diagnostics()
    out = Path("results/feasibility_checks.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out, index=False)
    print(df.to_string(index=False))
    print(f"Saved: {out.resolve()}")
