# Protatip2 - Geliştirilmiş Nöbetçi Eczane Modeli

Bu sürüm, protatip1 içindeki yer seçimi modelini korur ve nöbetçi eczane çizelgelemesini daha gerçekçi hale getirir.

## Eklenen ana dosyalar

- `src/pharmacy_location/advanced_duty_scheduler.py`
- `run_protatip2_duty_only.py`
- `results/duty_schedule_protatip2.xlsx`
- `results/duty_model_protatip2_report.xlsx`

## Protatip1'e göre farklar

Eski nöbet modeli sadece şunları yapıyordu:

- her gün sabit sayıda nöbetçi seçme,
- nöbetleri dengeli dağıtma,
- ardışık nöbeti engelleme.

Protatip2 modeli ayrıca şunları dikkate alır:

1. Talep noktası kapsaması  
   Her mahalle/talep noktası günlük nöbetçi eczanelere olan mesafesine göre değerlendirilir.

2. Hastane ve sağlık noktası kapsaması  
   Hastane, sağlık merkezi ve önemli sağlık noktalarının nöbetçi eczanelere erişimi kontrol edilir.

3. Nöbetçiler arası minimum mesafe  
   Aynı gün seçilen nöbetçilerin birbirine çok yakın olması engellenmeye çalışılır.

4. Dinlenme aralığı  
   Aynı eczanenin üst üste nöbet tutması engellenir.

5. Hafta sonu / özel gün ağırlığı  
   Hafta sonu ve özel günler daha yoğun nöbet yükü olarak kabul edilir.

6. Kapsama raporu  
   Her gün için ortalama mesafe, maksimum mesafe ve kapsama oranı üretilir.

## Çalıştırma

Tüm projeyi çalıştırmak için:

```bash
python main.py
```

Sadece gelişmiş nöbetçi eczane modelini çalıştırmak için:

```bash
python run_protatip2_duty_only.py
```

## Önemli ayarlar

`main.py` veya `run_protatip2_duty_only.py` içinde şu değerler değiştirilebilir:

```python
coverage_radius_m=2500.0
hospital_coverage_radius_m=2000.0
min_pair_distance_m=900.0
rest_gap_days=1
weekend_weight=1.30
holiday_weight=1.70
holiday_days=()
```

## Çıktılar

- `results/duty_schedule_protatip2.xlsx`: Gün gün nöbetçi eczaneler
- `results/duty_pharmacy_summary_protatip2.csv`: Eczane bazlı nöbet özeti
- `results/duty_coverage_summary_protatip2.csv`: Günlük kapsama performansı
- `results/duty_model_protatip2_report.xlsx`: Tüm raporun Excel dosyası

## Model yorumu

Bu model gerçek uygulamaya daha yakındır; çünkü yalnızca adil nöbet dağılımı yapmaz, aynı zamanda şehirdeki talep noktalarının ve hastanelerin nöbetçi eczanelerle günlük erişilebilirliğini de ölçer.
