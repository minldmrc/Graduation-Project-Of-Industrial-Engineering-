# Protatip7 Gerçekçilik Ayarları Notu

Bu sürüm protatip6 çıktı dosya yapısını korur. Ana `data/agirlik.xlsx` dosyası değiştirilmez.

Eklenen/ayarlanan yazılımsal parametreler:

- `demand_scale=1.5`: Talep ağırlıkları yalnızca model belleğinde 1.5 ile çarpılır. Excel dosyası bozulmaz.
- `max_capacity=4.0`: Bir eczanenin taşıyabileceği hizmet yükü azaltıldı; bu, daha fazla eczane açılmasını teşvik eder.
- `max_dist=4000.0`: Talep noktalarının uzaklık sınırı korunur; ana gerçekçilik etkisi kapasite ve talep ölçeklemeden gelir.
- `gamma=0.01`: Eczane açma cezası azaltıldı.
- `delta=0.30`: Hastane/sağlık noktasına yakınlık etkisi güçlendirildi.
- `alpha=0.35`, `beta=0.34`: Mesafe ve maksimum uzaklık etkisi korunarak katsayılar toplamı 1 olacak şekilde ayarlandı.

Bu değişiklikler modele doğrudan “en az 28 eczane aç” kısıtı koymaz; modelin gerçekçi hizmet yükü ve erişilebilirlik varsayımlarıyla daha fazla eczane açmasını sağlar.
